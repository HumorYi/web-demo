$(function(){
	$('#header').load('php/otherHeader.php');
	$('#footer').load('php/footer.php');
});