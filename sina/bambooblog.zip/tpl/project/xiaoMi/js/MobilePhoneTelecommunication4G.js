$(function(){
	$('#header').load('php/otherHeader.php');
	$('#footer').load('php/footer.php');
	
});
/*点击中间导航添加下边框 S*/
$(".purchase .purchase-all .container1 ul li").click(function(){
	$(this).addClass("first").siblings().removeClass("first");
});
/*点击中间导航添加下边框 E*/