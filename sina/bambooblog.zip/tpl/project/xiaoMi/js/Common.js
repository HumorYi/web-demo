$(function(){
	/*导航二级菜单 S*/
	$('#header').on('mouseenter','.header-nav ul li', function(){
		$(this).find(".navmenu").show();
	});
	$('#header').on('mouseleave','.header-nav ul li', function(){
		$(this).find(".navmenu").hide();
	});
	/*导航二级菜单 S*/

	/*点击搜索框显示搜索选项 S*/
	$('#header').on('click', 'input.search-text', function(e){
		$(this).css("border-color","#ff6670");
		$(".site-header .header-search").css("border-color","#ff6670");
		$(".site-header .header-search a.wristband").fadeOut(1000);
		$(".site-header .header-search a.phone").fadeOut(1000);
		$(".site-header .header-search .search-select").fadeIn(1000);
		e.stopPropagation();
	});
	//点击其它地方还原搜索框之前的状态
	$(document).on('click',function(){
		$(".site-header .header-search input.search-text").css("border-color","#e0e0e0");
		$(".site-header .header-search").css("border-color","#e0e0e0");
		$(".site-header .header-search a.wristband").fadeIn(1000);
		$(".site-header .header-search a.phone").fadeIn(1000);
		$(".site-header .header-search .search-select").fadeOut(500);
	});
	/*点击搜索框显示搜索选项 E*/

	/*鼠标移动到“全部商品分类”上面显示二级菜单 S */
	$('#header').on('mouseenter', '.nav-allproduct', function(){
		$(".all-nav").show();
	});
	$('#header').on('mouseleave', '.nav-allproduct', function(){
		$(".all-nav").hide();
	});
	/*鼠标移动到“全部商品分类”上面显示二级菜单 E */
});