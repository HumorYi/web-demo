<?php
	header('Content-Type:text/html; CharSet=utf-8');
?>

<!--all顶部 S-->
<div class="site-topbar">
	<!--顶部 S-->
	<div class="container">
		
		<!--顶部导航 S-->
		<div class="topbar-nav">
			<a href="http://www.mi.com/index.html">小米网</a>
			<span class="sep">|</span>
			<a href="http://www.miui.com/" target="_blank">MIUI</a>
			<span class="sep">|</span>
			<a href="http://www.miliao.com/" target="_blank">米聊</a>
			<span class="sep">|</span>
			<a href="http://game.xiaomi.com/" target="_blank">游戏</a>
			<span class="sep">|</span>
			<a href="http://www.duokan.com/" target="_blank">多看阅读</a>
			<span class="sep">|</span>
			<a href="https://i.mi.com/" target="_blank">云服务</a>
			<span class="sep">|</span>
			<a href="http://www.mi.com/c/appdownload/" target="_blank">小米网移动版</a>
			<span class="sep">|</span>
			<a href="http://static.mi.com/feedback/" target="_blank">问题反馈</a>
			<span class="sep">|</span>
			<a href="#J_modal-globalSites" target="_blank">Select Region</a>
		</div>
		<!--顶部导航 E-->

		<!--购物车 S-->
		<div class="topbar-car">
			<a href="http://static.mi.com/cart/" />
				<i class="iconfont">&#xe606;</i>
				<span>购物车( 0 )</span>
			</a>
		</div>
		<!--购物车 E-->

		<!--登录 注册 S-->
		<div class="topbar-info">
			<a href="http://static.mi.com/feedback/" target="_blank">登录</a>
			<span class="sep">|</span>
			<a href="#J_modal-globalSites" target="_blank">注册</a>
		</div>
		<!--登录 注册 E-->
	</div>
	<!--顶部 E-->
</div>
<!--all顶部 E-->

<!--all头部 S-->
<div class="site-head">
	<!--头部 S-->
	<div class="site-header">
		<!--logo S-->
		<a href='index.html' class="header-logo"></a>

		<!--logo E-->

		<!--头部导航 S-->
		<div class="header-nav">
			<ul>
				<li class="nav-item">
					<a class="name" href="#">小米手机</a>
						<div class="navmenu">
							<div  class="n-container">
								<ul>
									<li>
											<div class="figure">
												<a href="MobilePhone4c.html" target="_blank">
													<img src="images/mi4c!160x110.jpg" alt="小米手机4c" width="160" height="110" />
												</a>
											<div>
											<div class="title">
												<a href="MobilePhone4c.html">小米手机 4c</a>
											</div>
										<p>1299元起</p>
										<div class="halving-line"></div>
									</li>
									<li>
										<div class="figure">
											<a href="http://www.mi.com/mi4c/" target="_blank">
												<img src="images/mi4!160x110.jpg" alt="小米手机4c" width="160" height="110" />
											</a>
										<div>
										<div class="title">
											<a href="http://www.mi.com/mi4c/">小米手机 4</a>
										</div>
										<p>1299元起</p>
										<div class="halving-line"></div>
									</li>
									<li>
										<div class="figure">
											<a href="http://www.mi.com/mi4c/" target="_blank">
												<img src="images/minote!160x110.jpg" alt="小米手机4c" width="160" height="110" />
											</a>
										<div>
										<div class="title">
											<a href="http://www.mi.com/mi4c/">小米Note 标准版</a>
										</div>
										<p>1799元起</p>
										<div class="halving-line"></div>
									</li>
									<li>
										<div class="figure">
											<a href="http://www.mi.com/mi4c/" target="_blank">
												<img src="images/minotepro!160x110.jpg" alt="小米手机4c" width="160" height="110" />
											</a>
										<div>
										<div class="title">
											<a href="http://www.mi.com/mi4c/">小米Note 顶配版</a>
										</div>
										<p>2499元起</p>
									</li>
								</ul>
							</div>	
						</div>	
				</li>
				<li class="nav-item">
					<a class="name" href="#">红米</a>
					<div class="navmenu">
							<div  class="n-container">
								<ul>
									<li>
										<div class="figure">
											<a href="http://www.mi.com/hongmi2a/" target="_blank">
												<img src="images/hongmi2a!160x110.jpg" alt="红米手机2A 增强版" width="160" height="110" />
											</a>
										<div>
										<div class="title">
											<a href="http://www.mi.com/hongmi2a/">红米手机2A 增强版</a>
										</div>
										<p>特价499元</p>
										<div class="halving-line"></div>
									</li>
									<li>
										<div class="figure">
											<a href="http://www.mi.com/hongmi2/" target="_blank">
												<img src="images/hongmi2!160x110.jpg" alt="红米手机2" width="160" height="110" />
											</a>
										<div>
										<div class="title">
											<a href="http://www.mi.com/hongmi2/">红米手机2</a>
										</div>
										<p>599元起</p>
										<div class="halving-line"></div>
									</li>
									<li>
										<div class="figure">
											<a href="http://www.mi.com/note4gds/" target="_blank">
												<img src="images/note!160x110.jpg" alt="红米Note 电信版" width="160" height="110" />
											</a>
										<div>
										<div class="title">
											<a href="http://www.mi.com/note4gds/">红米Note 电信版</a>
										</div>
										<p>699元起</p>
										<div class="halving-line"></div>
									</li>
									<li>
										<div class="figure">
											<a href="http://www.mi.com/note2/" target="_blank">
												<img src="images/note2!160x110.jpg" alt="红米Note 2" width="160" height="110" />
											</a>
										<div>
										<div class="title">
											<a href="http://www.mi.com/note2/">红米Note 2</a>
										</div>
										<p>799元起</p>
										<div class="halving-line"></div>
									</li>
									<li>
										<div class="figure">
											<a href="http://www.mi.com/note3/" target="_blank">
												<img src="images/note3!160x110.jpg" alt="红米Note 3 width="160" height="110" />
											</a>
										<div>
										<div class="title">
											<a href="http://www.mi.com/note3/">红米Note 3</a>
										</div>
										<p>899元起</p>
									</li>
								</ul>
							</div>	
					</div>	
				</li>
				<li class="nav-item">
					<a class="name" href="#">平板</a>
					<div class="navmenu">
							<div  class="n-container">
								<ul>
									<li>
										<div class="figure">
											<a href="http://www.mi.com/mipad2/" target="_blank">
												<img src="images/mipad2-16!160x110.jpg" alt="小米平板2 16GB" width="160" height="110" />
											</a>
										<div>
										<div class="title">
											<a href="http://www.mi.com/mipad2/">小米平板2 16GB</a>
										</div>
										<p>999元</p>
										<div class="halving-line"></div>
									</li>
									<li>
										<div class="figure">
											<a href="http://www.mi.com/mipad2/" target="_blank">
												<img src="images/mipad2-64!160x110.jpg" alt="小米平板2 64GB" width="160" height="110" />
											</a>
										<div>
										<div class="title">
											<a href="http://www.mi.com/mipad2/">小米平板2 64GB</a>
										</div>
										<p>1299元</p>
										<div class="halving-line"></div>
									</li>
									<li>
										<div class="figure">
											<a href="http://www.mi.com/mipad2/" target="_blank">
												<img src="images/mipad2-64-win!160x110.jpg" alt="小米平板2  64GB Windows版" width="160" height="110" />
											</a>
										<div>
										<div class="title">
											<a href="http://www.mi.com/mi4c/">小米平板2  64GB Windows版</a>
										</div>
										<p>1299元</p>
									</li>
								</ul>
							</div>	
					</div>
				</li>
				<li class="nav-item">
					<a class="name" href="#">电视 · 盒子</a>
					<div class="navmenu">
							<div  class="n-container">
								<ul>
									<li>
										<div class="figure">
											<a href="http://www.mi.com/mitv40/" target="_blank">
												<img src="images/mitv40!160x110.jpg" alt="小米电视2 40英寸" width="160" height="110" />
											</a>
										<div>
										<div class="title">
											<a href="http://www.mi.com/mitv40/" target="_blank">小米电视2 40英寸</a>
										</div>
										<p>1799元起</p>
										<div class="halving-line"></div>
									</li>
									<li>
										<div class="figure">
											<a href="http://www.mi.com/mitv48/" target="_blank">
												<img src="images/mitv48!160x110.jpg" alt="小米电视2S 48英寸" width="160" height="110" />
											</a>
										<div>
										<div class="title">
											<a href="images/http://www.mi.com/mitv48/" target="_blank">小米电视2S 48英寸</a>
										</div>
										<p>2799元起</p>
										<div class="halving-line"></div>
									</li>
									<li>
										<div class="figure">
											<a href="http://www.mi.com/mitv3/55/" target="_blank">
												<img src="images/mitv3-55!160x110.jpg" alt="小米电视3 55英寸" width="160" height="110" />
											</a>
										<div>
										<div class="title">
											<a href="http://www.mi.com/mitv3/55/" target="_blank">小米电视3 55英寸</a>
										</div>
										<p>3999元起</p>
										<div class="halving-line"></div>
									</li>
									<li>
										<div class="figure">
											<a href="http://www.mi.com/mitv3/60/" target="_blank">
												<img src="images/mitv60!160x110.jpg" alt="小米电视3 60英寸" width="160" height="110" />
											</a>
										<div>
										<div class="title">
											<a href="http://www.mi.com/mi4c/"  target="_blank">小米电视3 60英寸</a>
										</div>
										<p>4999元起</p>
										<div class="halving-line"></div>
									</li>
									<li>
										<div class="figure">
											<a href="http://www.mi.com/tvzj/
											" target="_blank">
												<img src="images/tvzj.png" alt="小米电视主机" width="160" height="110" />
											</a>
										<div>
										<div class="title">
											<a href="http://www.mi.com/tvzj/" target="_blank">小米电视主机</a>
										</div>
										<p>999元起</p>
										<div class="halving-line"></div>
									</li>
									<li>
										<div class="figure">
											<a href="http://www.mi.com/hezi3/" target="_blank">
												<img src="images/hezi3.png" alt="小米盒子3" width="160" height="110" />
											</a>
										<div>
										<div class="title">
											<a href="http://www.mi.com/hezi3/"  target="_blank">小米盒子3</a>
										</div>
										<p>299元</p>
									</li>
								</ul>
							</div>	
					</div>
				</li>
				<li class="nav-item">
					<a class="name" href="#">路由器</a>
					<div class="navmenu">
							<div  class="n-container">
								<ul>
									<li>
										<div class="figure">
											<a href="http://www.mi.com/miwifi/" target="_blank">
												<img src="images/miwifi!160x110.jpg" alt="全新小米路由器" width="160" height="110" />
											</a>
										<div>
										<div class="title">
											<a href="http://www.mi.com/miwifi/"  target="_blank">全新小米路由器</a>
										</div>
										<p>899元起</p>
										<div class="halving-line"></div>
									</li>
									<li>
										<div class="figure">
											<a href="http://www.mi.com/miwifimini/" target="_blank">
												<img src="images/miwifimini!160x110.jpg" alt="小米路由器 mini" width="160" height="110" />
											</a>
										<div>
										<div class="title">
											<a href="http://www.mi.com/miwifimini/" target="_blank">小米路由器 mini</a>
										</div>
										<p>129元</p>
										<div class="halving-line"></div>
									</li>
									<li>
										<div class="figure">
											<a href="http://www.mi.com/miwifilite/" target="_blank">
												<img src="images/miwifilite!160x110.jpg" alt="小米路由器 青春版" width="160" height="110" />
											</a>
										<div>
										<div class="title">
											<a href="http://www.mi.com/miwifilite/" target="_blank">小米路由器 青春版</a>
										</div>
										<p>79元</p>
										<div class="halving-line"></div>
									</li>
									<li>
										<div class="figure">
											<a href="http://item.mi.com/1153200003.html" target="_blank">
												<img src="images/wifiExtension!160x110.jpg" alt="小米WiFi放大器" width="160" height="110" />
											</a>
										<div>
										<div class="title">
											<a href="http://www.mi.com/mi4c/" target="_blank">小米WiFi放大器</a>
										</div>
										<p>39元</p>
									</li>
								</ul>
							</div>	
					</div>
				</li>
				<li class="nav-item">
					<a class="name" href="#">智能硬件</a>
					<div class="navmenu">
							<div  class="n-container">
								<ul>
									<li>
										<div class="figure">
											<a href="http://www.mi.com/scooter/" target="_blank">
												<img src="images/scooter!160x110.jpg"  width="160" height="110" />
											</a>
										<div>
										<div class="title">
											<a href="http://www.mi.com/scale/"  target="_blank">九号平衡车</a>
										</div>
										<p>1999元起</p>
										<div class="halving-line"></div>
									</li>
									<li>
										<div class="figure">
											<a href="http://www.mi.com/mi4c/" target="_blank">
												<img src="images/scale!160x110.jpg" alt="体重秤" width="160" height="110" />
											</a>
										<div>
										<div class="title">
											<a href="http://www.mi.com/scale/" target="_blank">体重秤</a>
										</div>
										<p>99元起</p>
										<div class="halving-line"></div>
									</li>
									<li>
										<div class="figure">
											<a href="http://www.mi.com/xiaoyi/" target="_blank">
												<img src="images/xiaoyi!160x110.jpg" width="160" height="110" />
											</a>
										<div>
										<div class="title">
											<a href="http://www.mi.com/xiaoyi/" target="_blank">摄像机</a>
										</div>
										<p>149元起</p>
										<div class="halving-line"></div>
									</li>
									<li>
										<div class="figure">
											<a href="http://www.mi.com/yicamera/" target="_blank">
												<img src="images//yicamera!160x110.jpg" alt="运动相机" width="160" height="110" />
											</a>
										<div>
										<div class="title">
											<a href="http://www.mi.com/yicamera/" target="_blank">运动相机</a>
										</div>
										<p>399元起</p>
										<div class="halving-line"></div>
									</li>
									<li>
										<div class="figure">
											<a href="http://www.mi.com/ihealth/" target="_blank">
												<img src="images/ihealth!160x110.jpg" alt="血压计" width="160" height="110" />
											</a>
										<div>
										<div class="title">
											<a href="http://www.mi.com/ihealth/" target="_blank">血压计</a>
										</div>
										<p>199元起</p>
										<div class="halving-line"></div>
									</li>
									<li>
										<div class="figure">
											<a href="http://www.mi.com/smart/" target="_blank">
												<img src="images/smart!160x110.jpg" alt="查看全部<br/>智能硬件" width="160" height="110" />
											</a>
										<div>
										<div class="title">
											<a href="http://www.mi.com/smart/" target="_blank">查看全部<br/>智能硬件</a>
										</div>
										<p>399元起</p>
									</li>
								</ul>
							</div>	
					</div>
				</li>
				<li class="nav-item">
					<a class="name" href="#">服务</a>
				</li>
				<li class="nav-item">
					<a class="name" href="#">社区</a>
				</li>
			</ul>
		</div>
		<!--头部导航 E-->

		<!--搜索 S-->
		<div class="header-search">
			<input class="search-text" type="search" />
			<input class="search-btn iconfont" type="submit" value="&#xe602;" />
				<a class="wristband" href="http://search.mi.com/search_%E6%89%8B%E7%8E%AF">手环</a>
				<a class="phone" href="http://search.mi.com/search_%E5%B0%8F%E7%B1%B3%E6%89%8B%E6%9C%BA4">小米手机4</a>

				<!--搜索帮助选项 S-->
				<div class="search-select">
					<ul>
						<li>
							<a href="http://search.mi.com/search_%E7%A7%BB%E5%8A%A8%E7%94%B5%E6%BA%90">
								<span class="select-left">移动电源</span>
								<span class="select-right">约有22件</span>
							</a>
						</li>
						<li>
							<a href="http://search.mi.com/search_%E7%A9%BA%E6%B0%94%E5%87%80%E5%8C%96%E5%99%A8">
								<span class="select-left">空气净化器</span>
								<span class="select-right">约有2件</span>
							</a>
						</li>
						<li>
							<a href="http://search.mi.com/search_%E5%B0%8F%E7%B1%B3%E6%89%8B%E7%8E%AF">
								<span class="select-left">小米手环</span>
								<span class="select-right">约有5件</span>
							</a>
						</li>
						<li>
							<a href="http://search.mi.com/search_WiFi">
								<span class="select-left">WiFi</span>
								<span class="select-right">约有7件</span>
							</a>
						</li>
						<li>
							<a href="http://search.mi.com/search_%E8%87%AA%E6%8B%8D%E6%9D%86">
								<span class="select-left">自拍杆</span>
								<span class="select-right">约有4件</span>
							</a>
						</li>
						<li>
							<a href="http://search.mi.com/search_%E5%B0%8F%E7%B1%B3%E4%BD%93%E9%87%8D%E7%A7%A4">
								<span class="select-left">小米体重秤</span>
								<span class="select-right">约有1件</span>
							</a>
						</li>
						<li>
							<a href="http://search.mi.com/search_%E5%B0%8F%E8%9A%81%E6%91%84%E5%83%8F%E6%9C%BA">
								<span class="select-left">小蚁摄像机</span>
								<span class="select-right">约有2件</span>
							</a>
						</li>
						<li>
							<a href="http://search.mi.com/search_%E8%BF%90%E5%8A%A8%E7%9B%B8%E6%9C%BA">
								<span class="select-left">运动相机</span>
								<span class="select-right">约有2件</span>
							</a>
						</li>
						<li>
							<a href="http://search.mi.com/search_%E6%99%BA%E8%83%BD%E6%8F%92%E5%BA%A7">
								<span class="select-left">智能插座</span>
								<span class="select-right">约有5件</span>
							</a>
						</li>
						<li class="select-bottom">
							<a href="http://search.mi.com/search_%E9%85%8D%E4%BB%B6%E4%BC%98%E6%83%A0%E5%A5%97%E8%A3%85">
								<span class="select-left">配件优惠套装</span>
								<span class="select-right">约有15件</span>
							</a>
						</li>
					</ul>
				</div>
				<!--搜索帮助选项 E-->
		</div>	
		<!--搜索 E-->
	</div>	
	<!--头部 E-->
</div>	
<!--all头部 E-->