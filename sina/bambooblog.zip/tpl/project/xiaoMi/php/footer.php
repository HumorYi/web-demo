<?php
	header('Content-Type:text/html; CharSet=utf-8');
?>

<!--底部 S-->
<div class="bottom">
	<div class="bottom-message">
		<div class="message-top">
			<ul>
				<li>
					<a href="http://www.mi.com/service/exchange#repaire" target="_blank" style="border-left:0px solid #e0e0e0;">
						<i class="iconfont">&#xe609;</i>
						1小时快修服务
					</a>
				</li>
				<li>
					<a href="http://www.mi.com/service/exchange#repaire" target="_blank">
						<i class="iconfont">&#xe60b;</i>
						7天无理由退货
					</a>
				</li>
				<li>
					<a href="http://www.mi.com/service/exchange#repaire" target="_blank">
						<i class="iconfont">&#xe604;</i>
						15天免费换货
					</a>
				</li>
				<li>
					<a href="http://www.mi.com/service/exchange#repaire" target="_blank">
						<i class="iconfont">&#xe60c;</i>
						满150元包邮
					</a>
				</li>
				<li>
					<a href="http://www.mi.com/service/exchange#repaire" target="_blank">
						<i class="iconfont">&#xe60d;</i>
						520余家售后网点
					</a>
				</li>
			</ul>
		</div>
		<div class="message-bottom">
			<dl>
				<dt>帮助中心</dt>
				<dd>
					<a href="http://www.mi.com/service/help_center/guide/" target="_blank">购物指南</a>
				</dd>
				<dd>
					<a href="http://www.mi.com/service/help_center/pay/" target="_blank">支付方式</a>
				</dd>
				<dd>
					<a href="http://www.mi.com/service/help_center/delivery/" target="_blank">配送方式</a>
				</dd>
			</dl>
			<dl>
				<dt>服务支持</dt>
				<dd>
					<a href="http://www.mi.com/service/help_center/pay/" target="_blank">售后政策</a>
				</dd>
				<dd>
					<a href="http://fuwu.mi.com/" target="_blank">自助服务</a>
				</dd>
				<dd>
					<a href="http://xiazai.mi.com/" target="_blank">相关下载</a>
				</dd>
			</dl>
			<dl>
				<dt>小米之家</dt>
				<dd>
					<a href="http://www.mi.com/c/xiaomizhijia/" target="_blank">小米之家</a>
				</dd>
				<dd>
					<a href="http://www.mi.com/c/service/poststation/" target="_blank">服务网点</a>
				</dd>
				<dd>
					<a href="http://service.order.mi.com/mihome/index" target="_blank">预约亲临到店服务</a>
				</dd>
			</dl>
			<dl>
				<dt>关于小米</dt>
				<dd>
					<a href="http://www.mi.com/about" target="_blank">了解小米</a>
				</dd>
				<dd>
					<a href="http://hr.xiaomi.com/" target="_blank">加入小米</a>
				</dd>
				<dd>
					<a href="http://www.mi.com/about/contact" target="_blank">联系我们</a>
				</dd>
			</dl>
			<dl>
				<dt>关注我们</dt>
				<dd>
					<a href="http://e.weibo.com/xiaomishouji" target="_blank">购物指南</a>
				</dd>
				<dd>
					<a href="http://xiaoqu.qq.com/mobile/share/index.html?url=http%3A%2F%2Fxiaoqu.qq.com%2Fmobile%2Fbarindex.html%3Fwebview%3D1%26type%3D%26source%3Dindex%26_lv%3D25741%26sid%3D%26_wv%3D5123%26_bid%3D128%26%23bid%3D10525%26from%3Dwechat" target="_blank">小米部落</a>
				</dd>
				<dd>
					<a href="#J_modalWeixin" target="_blank">官方微信</a>
				</dd>
			</dl>
			<dl>
				<dt>特色服务</dt>
				<dd>
					<a href="http://order.mi.com/queue/f2code" target="_blank">F 码通道</a>
				</dd>
				<dd>
					<a href="http://www.mi.com/mimobile/" target="_blank">小米移动</a>
				</dd>
				<dd>
					<a href="http://huanxin.mi.com/" target="_blank">以旧换新</a>
				</dd>
			</dl>
			<div class="bottom-contact">
				<p class="ccontact-phone">400-100-5678</p>
				<p class="ccontact-time">
					<span>周一至周日 8:00-18:00</span><br />
					（仅收市话费）
				</p>
				<a href="http://www.mi.com/service/contact" target="_blank">
					<i class="iconfont">&#xe60f;</i>
					 24小时在线客服
				</a>
			</div>
		</div>
	</div>
</div>
<!--底部 E-->

<!--小米信息 S-->
<div class="info-bg">
	<div class="info">
		<div class="info-logo"></div>
		<div class="info-text">
			<p class="text-first">
				<a href="http://www.mi.com/index.html" target="_blank">小米网</a>
				<span>|</span>
				<a href="http://www.miui.com/" target="_blank">MIUI</a>
				<span>|</span>
				<a href="http://www.miliao.com/" target="_blank">米聊</a>
				<span>|</span>
				<a href="http://www.duokan.com/" target="_blank">多看书城</a>
				<span>|</span>
				<a href="http://www.miwifi.com/" target="_blank">小米路由器</a>
				<span>|</span>
				<a href="http://blog.xiaomi.com/" target="_blank">小米后院</a>
				<span>|</span>
				<a href="http://xiaomi.tmall.com/" target="_blank">小米天猫店</a>
				<span>|</span>
				<a href="http://shop115048570.taobao.com" target="_blank">小米淘宝直营店</a>
				<span>|</span>
				<a href="http://union.mi.com/" target="_blank">小米网盟</a>
				<span>|</span>
				<a href="http://static.mi.com/feedback/" target="_blank">问题反馈</a>
				<span>|</span>
				<a href="#J_modal-globalSites" target="_blank">Select Region</a>
				<span>|</span>
			</p>
			<p class="text-second">
				@<a href="http://www.mi.com/" target="_blank">mi.com</a>
				京ICP证110507号 京ICP备10046444号 京公网安备1101080212535号 
				 <a href="http://c1.mifile.cn/f/i/2013/cn/jingwangwen.jpg" target="_blank">京网文[2014]0059-0009号</a>
				违法和不良信息举报电话：185-0130-1238
			</p>
		</div>
		<div class="info-link">
			<a href="https://search.szfw.org/cert/l/CX20120926001783002010" target="_blank">
					<img src="images/v-logo-2.png" alt="诚信网站" />
			</a>
			<a href="https://ss.knet.cn/verifyseal.dll?sn=e12033011010015771301369&ct=df&pa=461082" target="_blank">
					<img src="images/v-logo-1.png" alt="可信网站" />
			</a>
			<a href="http://www.315online.com.cn/member/315140007.html" target="_blank">
					<img src="images/v-logo-3.png" alt="网上交易保障中心" />
			</a>
		</div>
	</div>
</div>
<!--小米信息 E-->