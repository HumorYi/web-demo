//登录验证和请求
$('#login')[0].onclick = function (e) {
    e = e || event;
    e.preventDefault();
    $.post({
        url: 'data/login.php',
        data: {
            uname: $('#uname').val(),
            upwd: $('#upwd').val()
        },
        success: function (data) {
            alert(data == 'success' ? '登录成功！' : '用户名或密码错误！');
            $('#uname').val('');
            $('#upwd').val('');
        },
        error: function () {
            alert('登录失败，请联系管理员！');
        }
    });
}

//注册验证和请求
$('#register')[0].onclick = function (e) {
    e = e || event;
    e.preventDefault();
    $.post({
        url: 'data/register.php',
        data: {
            uname: $('#uname').val(),
            upwd: $('#upwd').val()
        },
        success: function (data) {
            alert(data == 'exists' ? '很遗憾，用户名已存在！' : data == 'success' ? '恭喜您，注册成功！' : '很遗憾，注册失败!');
            $('#uname').val('');
            $('#upwd').val('');
        },
        error: function () {
            alert('注册失败，请联系管理员！');
        }
    });
}