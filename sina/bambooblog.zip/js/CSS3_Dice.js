/*矩阵旋转 S*/
var red, blue, yellow, pink, gray, green, flag = true, timer = null;
function get_box_divClassName1() {
    red = $(".rect-red")[0];
    blue = $(".rect-blue")[0];
    yellow = $(".rect-yellow")[0];
    pink = $(".rect-pink")[0];
    gray = $(".rect-gray")[0];
    green = $(".rect-green")[0];
}

$('.rotate #click_prev').click(function () {
    if (flag) {
        get_box_divClassName1();
        red.style.transform = "rotateX(90deg) translateZ(400px)";
        blue.style.transform = "rotateX(270deg) translateZ(400px)";
        yellow.style.transform = "rotateY(90deg) translateZ(400px)";
        pink.style.transform = "translateZ(400px)";
        gray.style.transform = "translateZ(-400px)";
        green.style.transform = "rotateY(270deg) translateZ(400px)";
        red.style.backgroundColor = "red";
        blue.style.backgroundColor = "blue";
        yellow.style.backgroundColor = "yellow";
        pink.style.backgroundColor = "pink";
        gray.style.backgroundColor = "gray";
        green.style.backgroundColor = "green";
        timer = setTimeout('changeRotateClassName1()', 2000);
        $('.rotate .btn_mask').css({'display': 'block', 'left': 140});
        flag = false;
    }
});

function changeRotateClassName1() {
    $('.rotate .btn_mask').css({'display': 'none'});
    get_box_divClassName1();
    red.style.transform =
        blue.style.transform =
            yellow.style.transform =
                pink.style.transform =
                    gray.style.transform =
                        green.style.transform = "";
    red.style.transition =
        blue.style.transition =
            yellow.style.transition =
                pink.style.transition =
                    gray.style.transition =
                        green.style.transition = "1s ease";
    red.className = "rect-reds";
    blue.className = "rect-blues";
    yellow.className = "rect-yellows";
    pink.className = "rect-pinks";
    gray.className = "rect-grays";
    green.className = "rect-greens";
}

function get_box_divClassName2() {
    red = $(".rect-reds")[0];
    blue = $(".rect-blues")[0];
    yellow = $(".rect-yellows")[0];
    pink = $(".rect-pinks")[0];
    gray = $(".rect-grays")[0];
    green = $(".rect-greens")[0];
    red.style.transition =
        blue.style.transition =
            yellow.style.transition =
                pink.style.transition =
                    gray.style.transition =
                        green.style.transition = "1s ease";
}

$('#click_next').click(function () {
    if (!flag) {
        clearTimeout(timer);
        get_box_divClassName2();
        red.style.transform = "rotateX(0) translateZ(450px)";
        blue.style.transform = "rotateX(0) translateZ(300px)";
        yellow.style.transform = "rotateY(0) translateZ(150px)";
        pink.style.transform = "translateZ(0px)";
        gray.style.transform = "translateZ(-150px)";
        green.style.transform = "rotateY(0) translateZ(-300px)";
        red.style.backgroundColor =
            blue.style.backgroundColor =
                yellow.style.backgroundColor =
                    pink.style.backgroundColor =
                        gray.style.backgroundColor =
                            green.style.backgroundColor = "pink";
        setTimeout('changeRotateClassName2()', 2000);
        $('.rotate .btn_mask').css({'display': 'block', 'left': 20});
        flag = true;
    }
});

function changeRotateClassName2() {
    $('.rotate .btn_mask').css({'display': 'none'});
    get_box_divClassName2();
    red.className = "rect-red";
    blue.className = "rect-blue";
    yellow.className = "rect-yellow";
    pink.className = "rect-pink";
    gray.className = "rect-gray";
    green.className = "rect-green";
}
/*矩阵旋转 E*/