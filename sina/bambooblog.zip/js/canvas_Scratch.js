//避免浏览器中 鼠标选中拖动文字事件 body 添加样式
var bodyStyle = document.body.style; //得到body对象
bodyStyle.mozUserSelect = 'none'; //moz
bodyStyle.webkitUserSelect = 'none'; //webkit

//定义我们的结果
//获取 canvas元素 并设置背景和位置属性
//五个结果 -》 每一次产生一个随机数字 -》0 1 2 3 4 对应着我们的结果图片
var img = new Image();
var canvas = document.querySelector('canvas');
canvas.style.backgroundColor = 'transparent';
canvas.style.cursor = 'pointer';
//	canvas.style.position = 'absolute';
var imgs = ['../../../imagesScratch//0.png','../../../images/Scratch/1.png','../../../images/Scratch/2.png','../../../images/Scratch/3.png','../../../images/Scratch/4.png'];
var num = Math.floor(Math.random()*10)%5;
//	console.log(num);
img.src = imgs[num];

//当我们进入主体的时候，检测图片加载完成的时候，定义一些属性和函数
img.addEventListener('load',function(e){
    var ctx ;
    var w = img.width;
    h = img.height;
    var offsetX = canvas.offsetLeft,
        offsetY = canvas.offsetTop;
    var mousedown = false; //ture false

    //绘制一个长方形 颜色为灰色
    function layer(ctx){
        ctx.fillStyle = 'gray';
        ctx.fillRect(0,0,w,h);
    }

    //鼠标按下事件和松开事件
    function eventDown(e){
        e.preventDefault();
        mousedown = true;
    }
    function eventUp(e){
        e.preventDefault();
        mousedown = false;
    }

    //定义移动事件 按下时候 获取坐标
    //绘制小圆点
    function eventMove(e){
        e.preventDefault();
        if(mousedown){
            if(e.changedTouches){
                e = e.changedTouches[e.changedTouches.length-1];
            }
            var x = (e.clientX + document.body.scrollLeft || e.pageX) - offsetX || 0,
                y = (e.clientY + document.body.scrollTop || e.pageY) - offsetY || 0;
            with(ctx){
                beginPath();
                arc(x,y,10,0,360*Math.PI/180);
                fill();
                closePath();
            }
        }
    }

    //canvas 调用
    canvas.width = w;
    canvas.height = h;
    canvas.style.backgroundImage = 'url('+img.src+')';
    ctx = canvas.getContext('2d');
    ctx.fillStyle = 'transparent';
    ctx.fillRect(0,0,w,h);
    layer(ctx);
    ctx.globalCompositeOperation = 'destination-out'; //很重要

    /*和对应的事件结合起来（手机端）
     canvas.addEventListener('touchstart',eventDown);
     canvas.addEventListener('touchend',eventUp);
     canvas.addEventListener('touchmove',eventMove);
     */

    //PC端
    canvas.addEventListener('mousedown',eventDown);
    canvas.addEventListener('mouseup',eventUp);
    canvas.addEventListener('mousemove',eventMove);
});