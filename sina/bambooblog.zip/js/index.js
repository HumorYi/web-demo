var serverError = '请求数据失败，请联系管理员';

$(function () {
    var skinCon_li = '';
    for (var i = 1; i < 6; i++) {
        skinCon_li += '<img src="images/tabs_adv' + i + '.jpg" alt="风景" />';

        if (i < 5) {
            $('.tabs .t-right .select_con .select_content:nth-of-type(1) ul.sel_imgList li:nth-of-type(' + i + ')').prepend('<img src="images/andy' + i + '.jpg" alt="andy" />');
            $('.tabs .t-right .select_con .select_content:nth-of-type(2) ul.sel_imgList li:nth-of-type(' + i + ')').prepend('<img src="images/linsy' + (6 + i) + '.jpg" alt="linsy" />');
            $('.tabs .t-right .select_con .select_content:nth-of-type(3) ul.sel_imgList li:nth-of-type(' + i + ')').prepend('<img src="images/cqy' + (4 + i) + '.jpg" alt="cqy" />');
        }
    }
    $('.tabs .t-left .imgCon .scrollCon').html(skinCon_li);

    //鼠标点击图片时，给body赋值更换背景图片
    $(".skin .scroll ul").on('click', ' li', function () {
        $("body").css({
            "background": "url(" + $(this).find("img").attr("dataSrc") + ") no-repeat fixed center / cover",
            "-webkit-backgroundSize": "cover",
            "-ms-backgroundSize": "cover",
            "-o-backgroundSize": "cover",
            "-moz-backgroundSize": "cover"
        });
    });

    //点击左按钮，切换效果
    var numClick = 1;
    $(".skin img.prev").click(function () {
        numClick++;
        if (numClick == 3) numClick = 2;
        $(".skin ul").animate({left: -904 * numClick}, 1000);
    });

    //点击右按钮，切换效果
    $(" .skin img.next").click(function () {
        numClick--;
        if (numClick == -1) numClick = 0;
        $(".skin .scroll ul").animate({left: -904 * numClick}, 1000);
    });

    $.get('data/accordion.php', function (data) {
        if (data.code == 1) {
            var liList = '';
            $.each(data.data, function (key, value) {
                liList += '<li><img src="images/' + value.src + '" alt="' + value.alt + '"/><span>' + value.textTop + '<br/>' + value.textCenter + '<br/>show</span></li>'
            });
            $('.sider>.list').html(liList);
            liList = null;
        } else {
            $('.sider>.list').html(serverError);
        }
    })
}());

/*鼠标滑动到logo图片时显示皮肤列表框 S*/
$(".header img.logo").hover(
    function () {
        $.get('data/bgImgList.php', function (data) {
            if (data.code == 1) {
                var imgList = '';
                $.each(data.data, function (key, value) {
                    imgList += "<li><img src='images/" + value.src + "' dataSrc='images/" + value.dataSrc + "' alt='" + value.alt + "' /></li>";
                });
                $(".skin ul").html(imgList);
                imgList = null;
            } else {
                $('.sider>.list').html(serverError);
            }
        });

        $(this).css({
            "-webkit-transform": "scale(1.1,1.1)",
            "-moz-transform": "scale(1.1,1.1)",
            "-ms-transform": "scale(1.1,1.1)",
            "-o-transform": "scale(1.1,1.1)",
            "transform": "scale(1.1,1.1)"
        });
        $(".skin-bg").fadeIn(1000);
        $(".skin-bg").click(function (e) {
            e.stopPropagation(); //阻止事件向上冒泡时间
        });
    }, function () {
        $(this).css({
            "-webkit-transform": "scale(1,1)",
            "-moz-transform": "scale(1,1)",
            "-ms-transform": "scale(1,1)",
            "-o-transform": "scale(1,1)",
            "transform": "scale(1,1)"
        });
    }
);
/*鼠标滑动到logo图片时显示皮肤列表框 E*/

/*点击八卦图显示播放器 S*/
$(".header .yin-yang").hover(function (e) {
    e = e || event;
    e.stopPropagation();
    $("#audio").fadeIn(1000);
    $("#audio").css("display", "inline-block");
});
/*点击八卦图显示播放器 E*/

/*导航条吸顶盒特效 S*/
$(window).scroll(function () {
    //获取滚动条距离上边的距离
    if ($(window).scrollTop() > 100) {
        $(".nav-bg").addClass("Top");
        $(".nav").css("background", "rgba(0, 0, 0, 0.2)");
    } else {
        $(".nav-bg").removeClass("Top");
        $(".nav").css("background", "rgba(0, 0, 0, 0.3)");
    }
});
/*导航条吸顶盒特效 E*/

/*点击搜索按钮显示搜索框等特效 S*/
$(".nav .search img").hover(function (e) {
    e.stopPropagation();
    $(this).css({
        "-webkit-border-radius": "12px 0px 0px 12px",
        "-moz-border-radius": "12px 0px 0px 12px",
        borderRadius: "12px 0px 0px 12px",

        "-webkit-transition": "1.5s",
        "-moz-transition": "1.5s",
        "-ms-transition": "1.5s",
        "-o-transition": "1.5s",
        transition: "1.5s"
    });
    $(".nav .search input").fadeIn(1300);
    $(".nav .search input").focus();
    $(".nav .search input").css({
        width: 160, right: -10,
        "-webkit-border-radius": '0px 12px 12px 0px',
        "-moz-border-radius": '0px 12px 12px 0px',
        borderRadius: '0px 12px 12px 0px'
    });
});
/*点击搜索按钮显示搜索框等特效 E*/

/*点击搜索框时添加样式 S*/
$(".nav .search input").click(function (e) {
    e.stopPropagation();
    $(".nav .search input").css({width: 170, right: -20, textIndent: 15});
});
/*点击搜索框时添加样式 S*/

/*导航二级菜单的实现 S*/
$(".nav ul li").hover(function () {
        $(this).find(".menu").fadeIn(1100);//显示 .menu 盒子
    }, function () {
        $(this).find(".menu").fadeOut(500);//隐藏
    }
);
/*导航二级菜单的实现 E*/

$(function () {
    /*头部轮播特效 S*/
    var timer = null, prev_index = 0, _index = 0;
    $('#banner').hover(function () {
        clearInterval(timer);
    }, function () {
        bannerPlay();
    });

    $("#banner").on("click", "ol li", function () {
        prev_index = _index;
        _index = $(this).index();
        $('#banner ul li').addClass('test').css('transform', function () {
                return 'translateZ(-180px) rotateX(' + prev_index * 90 + 'deg)';
            }
            //'transform', prev_index => prev_index
        );
        bannerCommon();
    });

    function bannerPlay() {
        timer = setInterval(function () {
            _index++;
            if (_index > 3) _index = 0;
            bannerCommon();
        }, 3000);
    }

    //设置共有属性
    function bannerCommon() {
        $("#banner ol li").eq(_index).addClass('on').siblings().removeClass('on');

        $('#banner ul li').removeClass('test').css(
            'transform', 'translateZ(-180px) rotateX(' + _index * 90 + 'deg)'
        );
    }

    //banner轮播个数
    function bannerNum(x) {
        var uhtml = '',//设置图片ul的内容
            phtml = '',//添加div背景定位
            zhtml = '', //设置选择器层级关系
            z = 0,//设置层级大小
            thtml = '',//设置各个div旋转时间
            lw = $('#banner').width() / x,//设置宽度
            selector = '';//设置选择器
        for (var i = 0; i < x; i++) {
            uhtml += '<li><div></div><div></div><div></div><div></div></li>';
            selector = '#banner ul li:nth-of-type(' + (i + 1) + ')';
            if (i >= x / 2) {
                z--;
                zhtml += selector + '{ z-index:' + z + '}';
            }
            phtml += selector + ' div{ background-position:' + (-i * lw) + 'px}';
            thtml += selector + '{ transition:1s ' + 0.5 * i / x + 's}';
        }
        $('#banner>ul').html(uhtml);

        /*动态生成html元素和css元素*/
        for (var j = 1; j < 5; j++) {
            $('#banner ul li div:nth-of-type(' + j + ')').css('backgroundImage', 'url(images/' + j + '.jpg)');
        }

        $('#banner ul li').css('width', lw + 'px');
        $('#banner ul li div').css('width', lw + 'px');
        $('#css').append(phtml + zhtml + thtml);
    }

    bannerNum(Math.floor(Math.random() * (200 - 3)) + 4);
    bannerPlay();
    /*头部轮播特效 E*/

    /*第二部分内容区广告轮播效果 S*/
    var _index2 = 0;
    var timeInterval = null;

    $("ul.scrollBut li").hover(function () {
            clearInterval(timeInterval);//清除定时器
            _index2 = $(this).index();
            partCommon();
        }, function () {
            partPlay();
        }
    );

    //构造自动轮播方法
    function partPlay() {
        //制作定时器
        timeInterval = setInterval(function () {
            if (_index2 <= 4) {
                if (_index2 == 4) {
                    _index2 = -1;
                }
                _index2++;
                partCommon();
            }
        }, 3000);
    };
    //构造函数方法(取相同属性)
    function partCommon() {
        $("ul.scrollBut li").eq(_index2).addClass("hover").siblings().removeClass("hover");
        $(".scrollCon").animate({left: "-" + _index2 * 339 + "px"}, 1000);
        $("ul.scrollTxt li").eq(_index2).show().siblings().hide();
    }

    partPlay();
    /*第二部分内容区广告轮播效果 E*/

    /*选项卡效果 S*/
    $("ul.select_but li").mouseover(function () {
        $(this).addClass("hover").siblings().removeClass("hover");//改变选项卡样式
        $(".select_con .select_content").eq($(this).index()).show().siblings().hide();//改变内容区
    });

    /*图片文字滑动效果 S*/
    $("ul.sel_imgList li").hover(function () {
        $(this).find("p").stop().animate({height: "60px"}, 200)
    }, function () {
        $(this).find("p").stop().animate({height: "0px"}, 200)
    });
    /*图片文字滑动效果 E*/
    /*选项卡效果 E*/
});

/*点击页面其它地区收缩皮肤框和隐藏搜索框 S*/
$(document).click(function () {
    $(".skin-bg").fadeOut(1000);
    $(".header img.logo").css("transform", "scale(1,1)");
    $(".nav .search input").fadeOut(1000);
    $(".nav .search input").css({width: 160, right: 0, textIndent: 10});
    $(".nav .search img").css('borderRadius', 12);
    $(".header #audio").fadeOut(2000);
});
/*点击页面其它地区收缩皮肤框和隐藏搜索框 E*/