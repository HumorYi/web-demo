$(function(){
  //验证用户名是否未输入
  var uname = $('.userMsg #uname')[0];
  var unameVal = '';

  uname.onfocus = function(){
    this.onkeydown = this.onkeyup = function(){
      testName(4,10,'用户名',/^[A-Za-z0-9\u4e00-\u9fa5]{1,10}$/);
    }
  }

  //验证密码是否未输入
  var upwd = $('.userMsg #upwd')[0];
  var upwdVal = '';

  upwd.onfocus = function(){
    this.onkeydown = this.onkeyup = function(){
      testPwd(8,16,'用户名');
    }
  }

  var errorPrompt = $('.userMsg>h3');
  //注册验证
  var markName = false;
  var markPwd = false;
  function testName(min,max,name,reg){
    unameVal = uname.value;
    markName = false;
    if(!unameVal) {
    }
    else{
      if(!reg.test(unameVal)){
        errorPrompt.html('用户名格式必须为中文或英文或数字');
        borderShow();
      }else{
        if(unameVal.length>=min&&unameVal.length<=max){
          markName = true;
          errorPrompt.html('');
          borderHide();
        }else{
          errorPrompt.html(name + '长度必须为' + min + '~' + max + '之间');
          borderShow();
        }
      }
    }
    btnState();
  }

  function testPwd(min,max,name){
    upwdVal = upwd.value;
    markPwd = false;
    if(!upwdVal){
    }else{
      if(upwdVal.length>=min&&upwdVal.length<=max){
        markPwd = true;
        borderHide();
      }else{
        errorPrompt.html(name+'长度必须为'+min+'~'+max+'之间');
        borderShow();
      }
    }
    btnState();
  }

  //注册按钮状态
  var btnRegister = $('#register');

  //判断按钮状态
  function btnState(){
    if(markName && markPwd){
      borderHide();
      errorPrompt.html('');
      btnRegister.attr('disabled', false);
      btnRegister.attr('enabled', true);
    }else{
      btnRegister.attr('disabled', true);
      btnRegister.attr('enabled', false);
    }
  }

  function borderShow(){
    errorPrompt.css("border","1px solid #962020");
  }

  function borderHide(){
    errorPrompt.css("border","none");
  }

  btnRegister[0].onclick = function(e){
    e = e || event;
    e.preventDefault();
    $.ajax({
      type: 'post',
      url: 'data/register.php',
      data: {
        uname: $('#uname').val(),
        upwd: $('#upwd').val()
      },
      success: function(data){
        alert(data=='exists' ? '很遗憾，用户名已存在！' : data=='success' ? '恭喜您，注册成功！' : '很遗憾，注册失败!');
        $('#uname').val('');
        $('#upwd').val('');
      }
    });
  }

  uname.focus();
})