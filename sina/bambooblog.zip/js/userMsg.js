//验证用户名是否未输入
var uname = $('.userMsg #uname')[0];
var unameVal = '';
uname.onblur = function(){
  testLogin(this,unameVal,'用户名');
}

uname.onfocus = function(){
  this.onkeyup = btnState;
}

//验证密码是否未输入
var upwd = $('.userMsg #upwd')[0];
var upwdVal = '';
upwd.onblur = function(){
  testLogin(this,upwdVal,'密码');
}

upwd.onfocus = function(){
  this.onkeyup = btnState;
}

var errorPrompt = $('.userMsg>h3');
//登录验证
function testLogin(obj,val,name){
  if(!(val=obj.value)){
    borderShow();
    errorPrompt.html(name+'不能为空');
  }else{
    borderHide();
    errorPrompt.html('');
  }
}

//登录按钮状态
var btnLogin = $('#login');
function btnState(){
  unameVal = uname.value;
  upwdVal = upwd.value;
  if(unameVal && upwdVal){
    btnLogin.attr('disabled',false);
    btnLogin.attr('enabled',true);
  }else{
    btnLogin.attr('disabled',true);
    btnLogin.attr('enabled',false);
  }
}

//注册验证
/*function testRegister(obj,val,name,min,max,reg/!**!/){
  if(!(val=obj.value)){
    borderShow();
    errorPrompt.html(name+'不能为空');
  }else if(val.length<min && val.length>max){
    borderShow();
    errorPrompt.html(name+'的长度必须在'+min+'~'+max+'之间！');
  }else if(reg){
    if(!reg.test(val)){
      borderShow();
      errorPrompt.html(name+'格式必须为英文或中文或数字或任意三者间的组合');
    }
  }else{
    borderHide();
  }
}*/

function borderShow(){
  errorPrompt.css("border","1px solid #962020");
}

function borderHide(){
  errorPrompt.css("border","none");
}

btnLogin[0].onclick = function(e){
  e = e || event;
  e.preventDefault();
  $.ajax({
    type: 'post',
    url: 'data/login.php',
    data: {
      uname: $('#uname').val(),
      upwd: $('#upwd').val()
    },
    success: function(data){
      alert(data=='success' ? '登录成功！' : '用户名或密码错误！');
      $('#uname').val('');
      $('#upwd').val('');
      btnLogin.attr('disabled',true);
      btnLogin.attr('enabled',false);
    }
  });
}
