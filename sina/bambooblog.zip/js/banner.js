/*轮播特效 S*/
$(function(){
  var timer = null, prev_index=_index=0;
  $('#banner').hover(function(){
    clearInterval(timer);
  },function(){
    bannerPlay();
  });

  $("#banner").on("click","ol li",function(){
    prev_index = _index;
    _index = $(this).index();
    $('#banner ul li').addClass('test').css(
      'transform', function(){
        return 'translateZ(-180px) rotateX('+prev_index*90+'deg)'
      }
      //'transform', prev_index => prev_index
    );
    common();
  });

  function bannerPlay(){
    timer = setInterval(function(){
      _index++;
      if(_index>3) _index=0;
      common();
    },3000);
  }

  function common(){
    $("#banner ol li").eq(_index).addClass('on').siblings().removeClass('on');

    $('#banner ul li').removeClass('test').css(
      'transform','translateZ(-180px) rotateX('+_index*90+'deg)'
    );
  }

  function play(x){
    var uhtml = '';
    var phtml = '';//添加div背景定位
    var zhtml = '',z=0;//设置层级关系
    var thtml = '';//设置各个div旋转时间
    var lw = $('#banner').width()/x;//设置宽度
    for (var i=0;i<x ;i++ ){
      uhtml += '<li><div></div><div></div><div></div><div></div></li>';
      var selector = '#banner ul li:nth-child('+(i+1)+')';
      if (i>=x/2){
        z--;
        zhtml += selector+'{ z-index:'+z+';}';
      }
      phtml += selector+' div{ background-position:'+(-i*lw)+'px;}';
      thtml += selector+'{ transition:1s '+0.5*i/x+'s;}';
    };
    $('#banner>ul').html(uhtml);

    /*动态生成html元素和css元素*/
    for(var j=1; j<5; j++){
      $('#banner ul li div:nth-child('+j+')').css('backgroundImage', 'url(images/'+j+'.jpg)');
    }

    $('#banner ul li').css('width',lw+'px');
    $('#banner ul li div').css('width',lw+'px');
    $('#css').append(phtml+zhtml+thtml);
  };
  play(Math.floor(Math.random()*(200-3))+4);
  bannerPlay();
});
/*轮播特效 E*/