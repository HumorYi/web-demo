/*发表说说 S*/

$.get('data/messageBoardFace.php',function (face) {
    if(face.code==1){
        for(var i=0, faceList = ''; i<face.data.length;i++){
            faceList += '<li><img src="images/'+face.data[i].src+'" title="'+face.data[i].title+'" /></li>';
        }
        $(".face ul").html(faceList);
        faceList = null;
        //点击表情，添加到div.edit
        $(".face ul").on('click','li',function (e) {
            e.stopPropagation();
            $(".edit_text").append($(this).find("img").clone());
        });
    }
});

var faceMark = true;
$(".but img.imgface").click(function (e) {
    e.stopPropagation();
    if(faceMark){
        $(".face").slideDown(); //慢慢乡下展开 event事件
        faceMark = false;
    }else {
        $(".face").slideUp(); //向上收缩
        faceMark = true;
    }
});

$(document).click(function () {
    $(".face").slideUp(); //向上收缩
});

$(".but .msg_but").click(function () {
    var txt = $(".edit_text").html(); //html 得到表情 会转换
    if (txt == "") {
        $(".edit_text").focus(); //获取焦点
    }
    else {
        $(".msgBox").append("<div class='msgInfo'><dl><dt><img src='images/psb.png' alt='logo' width='50' height='50' /></dt><dd>Tell Something</dd></dl><span>发表内容为：</span><div class='con'>" + txt + "</div></div>");
        $(".edit_text").html("");
    }
});

$(".but .msg_reset").click(function () {
    $(".edit_text").html("");
});
/*发表说说 E*/