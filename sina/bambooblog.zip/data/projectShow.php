<?php
    require('init.php');

    $output = [];
    $output['code'] = ($output['data']=mysqli_fetch_all(mysqli_query($conn, "select * from projectShow"),MYSQLI_ASSOC)) ? 1 : 0;
    echo json_encode($output);
?>