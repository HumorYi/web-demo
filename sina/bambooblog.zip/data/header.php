<?php
  header('Content-Type: text/html; charset=utf-8');
?>

<div class="nav navbar-default">
            <div class="container">
                <div class="navbar-header">
                    <a href="#menu" class="navbar-toggle" data-toggle="collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a>
                </div>

                <div id="menu" class="collapse navbar-collapse">
                    <ul class="nav navbar-nav link-effect">
                        <li><a href="HTML.html">HTML</a></li>
                        <li><a href="CSS.html">CSS</a></li>
                        <li><a href="JavaScript.html">JavaScript</a></li>
                        <li><a href="DOM.html">DOM</a></li>
                        <li><a href="JQuery.html">JQuery</a></li>
                        <li><a href="AJAX.html">AJAX</a></li>
                        <li><a href="HTML5.html">HTML5</a></li>
                        <li><a href="BOOTSTRAP.html">BOOTSTRAP</a></li>
                        <li><a href="ANGULARJS.html">ANGULARJS</a></li>
                        <li><a href="WEBAPP.html">WEBAPP</a></li>
                        <li><a href="JSFRAMEWORK.html">JSFRAMEWORK</a></li>
                        <li><a href="WEIXIN.html">WEIXIN</a></li>
                        <li><a href="NODEJS.html">NODEJS</a></li>
                    </ul>
                </div>
            </div>
        </div>