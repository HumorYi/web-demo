<?php
  require('init.php');
  header('Content-Type: text/plain; charset=utf-8');
  echo mysqli_fetch_assoc(mysqli_query($conn,"select * from user_msg where uname = '$_REQUEST[uname]' and upwd = '$_REQUEST[upwd]' ")) ? 'success' : 'error';
?>