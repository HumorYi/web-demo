<?php
  require('init.php');
  header('Content-Type: text/plain; charset=utf-8');
  if(mysqli_fetch_assoc(mysqli_query($conn, "select uname from user_msg where uname = '$_REQUEST[uname]' "))){
  		echo 'exists';
  }else{
  		echo mysqli_query($conn, "insert into user_msg values(null, '$_REQUEST[uname]', '$_REQUEST[upwd]')") ? 'success' : 'error';
  	}
?>