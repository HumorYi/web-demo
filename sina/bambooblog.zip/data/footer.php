<?php
    header('Content-Type: text/html; charset=utf-8');
?>
<div class="container">
    <div class="footer">
        <h3>博客内容由博主原创，要转载请注明出处，保护原创权人人有责！</h3>
        <h4>若有技术交流的想法，请给博主发邮件==》<span>luoxing8493@126.com</span>&nbsp;&nbsp;&nbsp;&nbsp;希望我们能够碰撞出技术的火花。</h4>
    </div>
</div>