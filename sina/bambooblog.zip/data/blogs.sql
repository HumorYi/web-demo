set names utf8;
create database blogs character set utf8;
use blogs;
#用户信息
create table user_msg(uid int primary key auto_increment, uname varchar(32) not null default '', upwd varchar(25) not null default '');
insert into user_msg values
(null,'luoxing','1'),
(null,'jerry','2')
;

#轮播图片信息
create table bgImg(bid int primary key auto_increment, src varchar(50) not null default '', dataSrc varchar(50) not null default '', alt varchar(20) not null default '' );
insert into bgImg values
(null,'s1.png','b1.png','最美的风景'),
(null,'s2.png','b2.png','春天的故事'),
(null,'s3.png','b3.png','等待爱情'),
(null,'s4.png','b4.png','梦境中的记忆'),
(null,'s5.png','b5.png','夏天的回忆'),
(null,'s6.png','b6.png','哥特魅影'),
(null,'s7.png','b7.png','盛夏之诗'),
(null,'s8.png','b8.png','爸比我们去哪里呀?'),
(null,'s9.png','b9.png','偏爱小清新'),
(null,'s10.png','b10.png','都市夜归人')
;

#导航条标题
create table nav(nid int primary key auto_increment, text varchar(8) not null default '');
insert into nav values
(null,'首页'),
(null,'项目展示'),
(null,'技术研究'),
(null,'学习总结'),
(null,'悟'),
(null,'关于黄坚毅'),
(null,'留言板')
;

#手风琴信息
create table accordion(aid int primary key auto_increment, src varchar(50) not null default '', alt varchar(20) not null default '', textTop varchar(8) not null default '',textCenter varchar(8) not null default '');
insert into accordion values
(null,'linsy1.jpg','Linsy','linsy','only'),
(null,'cqy1.jpg','QingYuan','qing','yuan'),
(null,'linsy2.jpg','Linsy','linsy','only'),
(null,'cqy2.jpg','QingYuan','qing','yuan'),
(null,'linsy4.jpg','QingYuan','HJY','linsy'),
(null,'cqy3.jpg','QingYuan','qing','yuan'),
(null,'linsy5.jpg','Linsy','linsy','only'),
(null,'cqy4.jpg','QingYuan','qing','yuan'),
(null,'linsy9.jpg','Linsy','linsy','only'),
(null,'cqy5.jpg','QingYuan','qing','yuan')
;

#留言板表情图片信息
create table messageBoardFace(fid int primary key auto_increment, src varchar(50) not null default '', title varchar(10) not null default '');
 insert into messageBoardFace values
 (null,'88_thumb.gif','[拜拜]'),
 (null,'angrya_thumb.gif','[发怒]'),
 (null,'boboshengmenqi_thumb.gif','[生气]'),
 (null,'bofubianlian_thumb.gif','[发功]'),
 (null,'bs2_thumb.gif','[鄙视]'),
 (null,'cake.gif','[蛋糕]'),
 (null,'camera_thumb.gif','[相机]'),
 (null,'cat_yunqizhong_thumb.gif','[小猫]'),
 (null,'cf_thumb.gif','[得意]'),
 (null,'chn_buyaoya_thumb.gif','[不要呀]'),
 (null,'clock_thumb.gif','[时钟]'),
 (null,'come_thumb.gif','[勾引]'),
 (null,'cool_thumb.gif','[酷]'),
 (null,'crazya_thumb.gif','[抓狂]'),
 (null,'cry.gif','[衰]'),
 (null,'cza_thumb.gif','[挑逗]'),
 (null,'daxiongleibenxiong_thumb.gif','[奔跑]'),
 (null,'fuyun_thumb.gif','[浮云]'),
 (null,'gbzkun_thumb.gif','[困死了]'),
 (null,'good_thumb.gif','[强]'),
 (null,'gza_thumb.gif','[鼓掌]'),
 (null,'h_thumb.gif','[流汗]'),
 (null,'hatea_thumb.gif','[讨厌]'),
 (null,'hearta_thumb.gif','[爱心]'),
 (null,'heia_thumb.gif','[偷笑]'),
 (null,'horse2_thumb.gif','[神马]'),
 (null,'hsa_thumb.gif','[色]'),
 (null,'hufen_thumb.gif','[互粉]'),
 (null,'j_thumb.gif','[囧]'),
 (null,'k_thumb.gif','[好困啊]'),
 (null,'kbsa_thumb.gif','[勾鼻]'),
 (null,'kl_thumb.gif','[可怜]'),
 (null,'lazu_thumb.gif','[蜡烛]'),
 (null,'ldln_thumb.gif','[gg]'),
 (null,'liwu_thumb.gif','[礼物]'),
 (null,'lxhluguo_thumb.gif','[路过]'),
 (null,'lxhzhuanfa_thumb.gif','[自己疯]'),
 (null,'m_thumb.gif','[麦克风]'),
 (null,'mb_thumb.gif','[可惜]'),
 (null,'money_thumb.gif','[钱迷]'),
 (null,'nm_thumb.gif','[咒骂]'),
 (null,'no_thumb.gif','[你不行]'),
 (null,'ok_thumb.gif','[好的]'),
 (null,'otm_thumb.gif','[流鼻涕]'),
 (null,'panda_thumb.gif','[熊猫]'),
 (null,'pig.gif','[猪]'),
 (null,'qq_thumb.gif','[亲亲]'),
 (null,'rabbit_thumb.gif','[兔子]'),
 (null,'sad_thumb.gif','[烂]'),
 (null,'sada_thumb.gif','[大哭]'),
 (null,'sb_thumb.gif','[傻逼]'),
 (null,'shamea_thumb.gif','[放电]'),
 (null,'sk_thumb.gif','[思考]'),
 (null,'sleepa_thumb.gif','[打呼噜]'),
 (null,'sleepya_thumb.gif','[好困]'),
 (null,'smilea_thumb.gif','[微笑]'),
 (null,'sw_thumb.gif','[忏愧]'),
 (null,'sweata_thumb.gif','[流汗]'),
 (null,'t_thumb.gif','[吐]'),
 (null,'tootha_thumb.gif','[嬉笑]'),
 (null,'tza_thumb.gif','[害羞]'),
 (null,'unheart.gif','[心碎了]'),
 (null,'vw_thumb.gif','[九五至尊]'),
 (null,'weijin_thumb.gif','[围巾]'),
 (null,'wg_thumb.gif','[全家福]'),
 (null,'wq_thumb.gif','[委屈]'),
 (null,'ye_thumb.gif','[胜利了]'),
 (null,'yhh_thumb.gif','[右哼哼]'),
 (null,'youqian_thumb.gif','[有钱]'),
 (null,'bgl.gif','[扮鬼脸]')
 ;

 #项目展示
 create table projectShow (pid int primary key auto_increment, src varchar(50) not null default '', title varchar(10) not null default '');
 insert into projectShow values
 (null,'canvas_Clock.jpg','canvas时钟'),
 (null,'canvas_hackerMatrixText.jpg','canvas骇客帝国文字'),
 (null,'canvas_Hero.jpg','canvas英雄'),
 (null,'canvas_Scratch.jpg','canvas刮刮乐'),
 (null,'canvas_Snake.jpg','canvas贪吃蛇'),
 (null,'canvas_Sun.jpg','canvas太阳系'),
 (null,'canvas_ThanksGiving.jpg','canvas感恩节'),
 (null,'canvas_Turntable.jpg','canvas转盘'),
 (null,'xiaoMi.jpg','小米'),
 (null,'3D_Flop.jpg','3D翻牌效果'),
 (null,'3D_Rotate.jpg','3D旋转'),
 (null,'360stairs.jpg','360楼梯'),
 (null,'CSS3_Clock.jpg','CSS3时钟'),
 (null,'CSS3_Dice.jpg','CSS3色子'),
 (null,'CSS3_Move.jpg','CSS3移动'),
 (null,'CSS3_Nav.jpg','CSS3导航'),
 (null,'CSS3_Photo.jpg','CSS3相册'),
 (null,'CSS3_SolarSystem.jpg','CSS3太阳系'),
 (null,'CSS3_Twinkle.jpg','CSS3闪烁'),
 (null,'CSS3_Window-blinds.jpg','CSS3百叶窗'),
 (null,'pick.jpg','美女来找茬')
 ;