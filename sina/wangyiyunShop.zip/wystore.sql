-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 2018-09-12 14:21:26
-- 服务器版本： 10.1.19-MariaDB
-- PHP Version: 5.6.28

--
-- Database: `wystore`
--

-- --------------------------------------------------------

--
-- 表的结构 `wy_index_carousel`
--

CREATE TABLE `wy_index_carousel` (
  `cid` int(11) NOT NULL,
  `img` varchar(128) NOT NULL,
  `bg_color` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `wy_index_carousel`
--

INSERT INTO `wy_index_carousel` (`cid`, `img`, `bg_color`) VALUES
(1, 'img/banner/banner1.png', 'background: #1E1E1E'),
(2, 'img/banner/banner2.png', 'background: #C70F0F'),
(3, 'img/banner/banner3.png', 'background: #46B3A0'),
(4, 'img/banner/banner4.png', 'background: #BDFFFE'),
(5, 'img/banner/banner5.png', 'background: #0C0C16'),
(6, 'img/banner/banner6.png', 'background: #191919'),
(7, 'img/banner/banner7.png', 'background: #BD3EE3');

-- --------------------------------------------------------

--
-- 表的结构 `wy_product`
--

CREATE TABLE `wy_product` (
  `pid` int(11) NOT NULL,
  `details` varchar(128) CHARACTER SET utf8 NOT NULL,
  `pic` varchar(128) NOT NULL,
  `href` varchar(128) NOT NULL,
  `price` int(11) NOT NULL,
  `original_price` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `wy_product`
--

INSERT INTO `wy_product` (`pid`, `details`, `pic`, `href`, `price`, `original_price`) VALUES
(1, '【网易云音乐专供款】击音者XT800金属磁吸入耳式HiFi耳机', 'img/recom_1.jpg', 'product_details.html', 59, 79),
(2, '【下单赠毛绒本】哆啦A梦cloudlele系列·记忆尤克里里D1款入门款', 'img/recom_2.jpg', 'product_details.html', 458, 598),
(3, '【赠毛绒本】哆啦A梦cloudlele系列·记忆尤克里里D2单板高端款', 'img/recom_3.jpg', 'product_details.html', 788, 1588),
(4, '【网易云音乐专供款】漫步者W800X立体声头戴式蓝牙耳机', 'img/recom_4.jpg', 'product_details.html', 199, 259),
(5, '网易云音乐无线蓝牙音箱MB1', 'img/product_1.jpg', 'product_details.html', 399, NULL),
(6, 'Beats Solo3 Wireless 头戴式耳机 无线蓝牙带麦', 'img/product_2.jpg', 'product_details.html', 2288, NULL),
(7, '漫步者（EDIFIER） H230P 入耳式立体声线控耳机', 'img/product_3.jpg', 'product_details.html', 69, NULL),
(8, '网易云音乐蓝牙自拍杆 移动充电三挡补光', 'img/product_4.jpg', 'product_details.html', 139, 199);

-- --------------------------------------------------------

--
-- 表的结构 `wy_product_details`
--

CREATE TABLE `wy_product_details` (
  `did` int(11) NOT NULL,
  `color_title` varchar(64) CHARACTER SET utf8 NOT NULL,
  `title` varchar(128) CHARACTER SET utf8 NOT NULL,
  `min_img` varchar(128) NOT NULL,
  `middle_img` varchar(128) NOT NULL,
  `max_img` varchar(128) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `wy_product_details`
--

INSERT INTO `wy_product_details` (`did`, `color_title`, `title`, `min_img`, `middle_img`, `max_img`, `price`) VALUES
(1, '黑色', 'Beats Solo3 Wireless 头戴式耳机 无线蓝牙带麦', 'img/product/smallimgBox_1.jpg', 'img/product/imgBox_1.jpg', 'img/product/bigimgBox_1.png', 2288),
(2, '炫黑色', 'Beats Solo3 Wireless 头戴式耳机 无线蓝牙带麦', 'img/product/smallimgBox_2.jpg', 'img/product/imgBox_2.jpg', 'img/product/bigimgBox_2.png', 2288),
(3, '橘红色', 'Beats Solo3 Wireless 头戴式耳机 无线蓝牙带麦', 'img/product/smallimgBox_3.jpg', 'img/product/imgBox_3.jpg', 'img/product/bigimgBox_3.png', 2288),
(4, '哑光金', 'Beats Solo3 Wireless 头戴式耳机 无线蓝牙带麦', 'img/product/smallimgBox_4.jpg', 'img/product/imgBox_4.jpg', 'img/product/bigimgBox_4.png', 2288),
(5, '哑光银', 'Beats Solo3 Wireless 头戴式耳机 无线蓝牙带麦', 'img/product/smallimgBox_5.jpg', 'img/product/imgBox_5.jpg', 'img/product/bigimgBox_5.png', 2288),
(6, '炫白色', 'Beats Solo3 Wireless 头戴式耳机 无线蓝牙带麦', 'img/product/smallimgBox_6.jpg', 'img/product/imgBox_6.jpg', 'img/product/bigimgBox_6.png', 2288),
(7, '金色', 'Beats Solo3 Wireless 头戴式耳机 无线蓝牙带麦', 'img/product/smallimgBox_7.jpg', 'img/product/imgBox_7.jpg', 'img/product/bigimgBox_7.png', 2288),
(8, '银色', 'Beats Solo3 Wireless 头戴式耳机 无线蓝牙带麦', 'img/product/smallimgBox_8.jpg', 'img/product/imgBox_8.jpg', 'img/product/bigimgBox_8.png', 2288);

-- --------------------------------------------------------

--
-- 表的结构 `wy_shoppingcart`
--

CREATE TABLE `wy_shoppingcart` (
  `cart_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `did` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `is_checked` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `wy_shoppingcart`
--

INSERT INTO `wy_shoppingcart` (`cart_id`, `uid`, `did`, `count`, `is_checked`) VALUES
(93, 1, 6, 5, 0),
(95, 1, 3, 3, 1),
(100, 1, 1, 7, 1);

-- --------------------------------------------------------

--
-- 表的结构 `wy_user`
--

CREATE TABLE `wy_user` (
  `uid` int(11) NOT NULL,
  `uname` varchar(32) NOT NULL,
  `upwd` varchar(32) NOT NULL,
  `email` varchar(64) NOT NULL,
  `phone` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `wy_user`
--

INSERT INTO `wy_user` (`uid`, `uname`, `upwd`, `email`, `phone`) VALUES
(1, 'liangliang', '123456', 'liangliang@qq.com', '15766666666'),
(2, '123', '1234567', '', '15777777777');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wy_index_carousel`
--
ALTER TABLE `wy_index_carousel`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `wy_product`
--
ALTER TABLE `wy_product`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `wy_product_details`
--
ALTER TABLE `wy_product_details`
  ADD PRIMARY KEY (`did`);

--
-- Indexes for table `wy_shoppingcart`
--
ALTER TABLE `wy_shoppingcart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `wy_user`
--
ALTER TABLE `wy_user`
  ADD PRIMARY KEY (`uid`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `wy_index_carousel`
--
ALTER TABLE `wy_index_carousel`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- 使用表AUTO_INCREMENT `wy_product`
--
ALTER TABLE `wy_product`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- 使用表AUTO_INCREMENT `wy_product_details`
--
ALTER TABLE `wy_product_details`
  MODIFY `did` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- 使用表AUTO_INCREMENT `wy_shoppingcart`
--
ALTER TABLE `wy_shoppingcart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;
--
-- 使用表AUTO_INCREMENT `wy_user`
--
ALTER TABLE `wy_user`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;