<?php

require("../init.php");

$sql = "SELECT * FROM wy_product_details";

$result = mysqli_query($conn,$sql);
echo json_encode(mysqli_fetch_all($result,1));




?>