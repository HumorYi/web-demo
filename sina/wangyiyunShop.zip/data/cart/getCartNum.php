<?php
//data/cart/getCartNum.php
require_once("../init.php");

@$uid=$_REQUEST["uid"];

$sql = "SELECT SUM(count) FROM wy_shoppingcart WHERE uid=$uid";

$result = mysqli_query($conn,$sql);

$sum =mysqli_fetch_row($result);

echo ($sum[0]);
?>