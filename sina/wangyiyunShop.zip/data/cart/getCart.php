<?php
require_once("../init.php");

@$uid=$_REQUEST["uid"];
if($uid!=null){
	$sql = "SELECT * FROM wy_product_details as pd INNER JOIN wy_shoppingcart as sc ON pd.did = sc.did where sc.uid = $uid";

	$result=mysqli_query($conn,$sql);
	echo json_encode(mysqli_fetch_all($result,1));
}

