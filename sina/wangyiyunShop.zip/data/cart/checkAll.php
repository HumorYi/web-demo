<?php
//data/cart/checkAll.php
require_once("../init.php");
@$uid=$_REQUEST["uid"];
@$checked=$_REQUEST["checked"];
if($uid!=null && $checked!=null){
	$sql="update wy_shoppingcart set is_checked=$checked where uid=$uid";
	$result=mysqli_query($conn,$sql);
}







?>