<?php
//data/cart/addCart.php
require_once("../init.php");

@$uid=$_REQUEST["uid"];
@$did=$_REQUEST["did"];
@$count=$_REQUEST["count"];

if($uid!=null&&$did!=null&&$count!=null){
	$sql="select * from wy_shoppingcart where uid=$uid and did=$did";
	$result=mysqli_query($conn,$sql);
	if(mysqli_fetch_row($result)==null){
		$sql="insert into wy_shoppingcart values (null,$uid,$did,$count,1)";
	}
	else{
		$sql="update wy_shoppingcart set count=count+$count where uid=$uid and did=$did";
	}
	$result=mysqli_query($conn,$sql);
	if(mysqli_affected_rows($conn)>=1){
		echo'{"code":1,"msg":"加入购物车成功！"}';
	}else{
		echo'{"code":-1,"msg":"加入购物车失败！请联系管理员！"}';
	}
}
