<?php
//data/cart/delete.php
require_once("../init.php");
@$cart_id=$_REQUEST["cart_id"];
if($cart_id!=null){
	$sql="delete from wy_shoppingcart where cart_id=$cart_id";
	mysqli_query($conn,$sql);
}








?>