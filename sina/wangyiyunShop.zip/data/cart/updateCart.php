<?php
//data/cart/updateCart.php
require_once("../init.php");
@$cart_id=$_REQUEST["cart_id"];
@$count=$_REQUEST["count"];
if($cart_id!=null&&$count!=null){
	if($count>=1){
		$sql="update wy_shoppingcart set count=$count where cart_id=$cart_id";
	}
	mysqli_query($conn,$sql);
}

?>