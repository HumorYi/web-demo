<?php
//data/cart/check.php
require_once("../init.php");
@$cart_id=$_REQUEST["cart_id"];
@$checked=$_REQUEST["checked"];
if($cart_id!=null & $checked!=null){
	$sql="update wy_shoppingcart set is_checked=$checked where cart_id=$cart_id";
	mysqli_query($conn,$sql);
}






?>