<?php
header('Content-Type:text/html;charset=utf-8');
require_once('../init.php');



@$uname=$_REQUEST['uname'];
@$upwd=$_REQUEST['upwd'];
$uname_preg='/^(\w|[\x{4e00}-\x{9fa5}]){2,20}$/u';
if(!preg_match($uname_preg,$uname)){
    die('用户名格式不正确');
};
$uname_preg='/^[\w]{6,20}$/';
if(!preg_match($uname_preg,$upwd)){
    die('密码格式不正确');
};


$sql="SELECT uid,uname,upwd FROM wy_user WHERE uname='$uname' AND upwd='$upwd'";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($result);
if($row===null){
    echo '{"code":-1,"msg":"登录失败!用户名或密码不正确"}';
}else{
    echo '{"code":1,"msg":"登录成功!","id":'.$row['uid'].'}';
}

mysqli_close($conn);

?>