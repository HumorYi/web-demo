<?php
header('Content-Type:text/html;charset=utf-8');
require_once('../init.php');

@$uname=$_REQUEST['uname'];
$uname_preg='/^(\w|[\x{4e00}-\x{9fa5}]){2,20}$/u';
if(!preg_match($uname_preg,$uname)){
    die('用户名格式不正确');
};

$sql="SELECT uname FROM wy_user WHERE uname='$uname' ";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_row($result);

if($row===null){
    echo '{"code":1,"msg":"用户名可用"}';
}else{
    echo '{"code":-1,"msg":"用户名被占用"}';
}



mysqli_close($conn);