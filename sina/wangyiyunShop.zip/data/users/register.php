<?php
header('Content-Type:text/html;charset=utf-8');
require_once('../init.php');

@$uname=$_REQUEST['uname'];//用户名
@$upwd=$_REQUEST['upwd'];//密码
@$phone=$_REQUEST['phone'];//手机
$uname_preg='/^(\w|[\x{4e00}-\x{9fa5}]){2,20}$/u';
if(!preg_match($uname_preg,$uname)){
    die('用户名格式不正确');
};
$uname_preg='/^[\w]{6,20}$/';
if(!preg_match($uname_preg,$upwd)){
    die('密码格式不正确');
};
$uname_preg='/^[1][3,4,5,7,8][0-9]{9}$/';
if(!preg_match($uname_preg,$phone)){
    die('手机号格式不正确');
};

$sql="INSERT  INTO wy_user (uname,upwd,phone) VALUES('$uname',('$upwd'),'$phone')";
$result=mysqli_query($conn,$sql);
if($result==true){
    echo '{"code":1,"msg":"注册成功"}';
}else{
    echo '{"code":-1,"msg":"注册失败"}';
}
mysqli_close($conn);