<?php
header('Content-Type:text/html;charset=utf-8');
require_once('../init.php');

@$phone=$_REQUEST['phone'];
$preg='/^[1][3,4,5,7,8][0-9]{9}$/';
if(!preg_match($preg,$phone)){
    die('手机格式不正确');
};

$sql="SELECT phone FROM wy_user WHERE phone='$phone' ";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_row($result);

if($row===null){
    echo '{"code":1,"msg":"手机号可用"}';
}else{
    echo '{"code":-1,"msg":"手机号已被注册"}';
}



mysqli_close($conn);