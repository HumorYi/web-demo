$(function(){
    var unameSwitch=false;
    var upwdSwitch=false;

    //用户名输入框失去焦点，正则判断
    $('#login .uname').blur(function(){
        if(/^[\w\u4e00-\u9fa5]{2,20}$/.test($(this).val())){
            $(this).siblings('span').fadeIn(600).attr('class','success');
            setTimeout(()=>{$(this).siblings('span').html('用户名格式正确').fadeOut(3000)},0);
            unameSwitch=true;
        }else {
            $(this).siblings('span').fadeIn(3000).html('用户名不符合规则').attr('class', 'warning');
            unameSwitch=false;
        }
    });
    //密码输入框失去焦点，正则判断
    $('#login .upwd').blur(function(){
        if(/^[\w]{6,20}$/.test($(this).val())){
            $(this).siblings('span').fadeIn(600).attr('class','success');
            setTimeout(()=>{$(this).siblings('span').html('密码格式正确').fadeOut(3000)},0);
            upwdSwitch=true;
        }else {
            $(this).siblings('span').fadeIn(3000).html('密码不符合规则').attr('class', 'warning');
            upwdSwitch=false;
        }
    });
    //点击登录按钮
    $('#login .login_but').click(function(){
        if(unameSwitch===true && upwdSwitch===true){
            $.ajax({
                type:'GET',
                data:{uname:$('#login .uname').val(),upwd:$('#login .upwd').val()},
                url:'data/users/login.php',
                dataType:'JSON',
                success:function (data){
                    if(data.code>0){
                        localStorage.setItem('wyUserName',$('#login .uname').val());//保存用户名
                        localStorage.setItem('wyUserId',data.id);//保存用户ID
                        alert('登录成功!');
                        location.replace('index.html');
                    }else{
                        alert('登录失败!请检查用户名或者密码');
                    }
                },
                error:function (){
                    alert('网络错误请检查!');
                }
            })
        }else{
            alert('用户名或密码不符合规则!');
        }
    })
});