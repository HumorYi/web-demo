$(function (){
    var link=document.createElement("link");
    link.rel="stylesheet";
    link.href="css/header.css";
    document.head.appendChild(link);
    $("#g_top").load("header.html",function (html){
        document.getElementById("g_top").innerHTML=html;

        //购物车跳转
        $(".shopcar").on("click",function (e){
            e.preventDefault();
            window.location.href = "shopcart.html";
        });

        //登录判断
        var $lar = $(".lar");
        var $isLogin = $(".isLogin");

        if(localStorage.getItem('wyUserName')){
            console.log(localStorage.getItem('wyUserName'));
            console.log("已登录");
            $lar.hide();
             $isLogin.show();
        }else{
            console.log("未登录");
            $lar.show();
            $isLogin.hide();
        }

        //退出登录
        $(".logoutspan").click(function (){
            if(confirm("确定不再逛逛吗？")){
                localStorage.clear('wyUserName');
                localStorage.clear('wyUserId');
                alert("退出登录成功！");
                location.replace('index.html');
            }
        });

        //用户登录后，显示用户购物车数量
        if(localStorage.getItem('wyUserId')){
            var $cartNum = $(".j-cartnum");
            $.ajax({
                type:"GET",
                url:"data/cart/getCartNum.php",
                data:{uid:localStorage.getItem('wyUserId')},
                success:function (res){
                    if(res!=""){
                        $cartNum.html(res);
                    }else{
                        $cartNum.html(0);
                    }
                }
            });
        }
    });
});
