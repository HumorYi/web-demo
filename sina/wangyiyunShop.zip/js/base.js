$(function (){
    //���ﳵ��ť��ʽ
    function dis($input){
        if($input.val()>1){
            $input.parent().prev().removeClass("btn-dis");
        }else{
            $input.parent().prev().addClass("btn-dis");
        }
    }

    //���ӹ�������
    $(".shopCounting").on("click", ".u-icn-28", function (e){
        var $input = $(this).parent().siblings("span.tot").find(".text");
        var val = $input.val();
        ++val;
        $input.val(val);
        dis($input);
    });

    //���ٹ�������
    $(".shopCounting").on("click", ".u-icn-27", function (e){
        var $input = $(this).parent().siblings("span.tot").find(".text");
        var val = $input.val();

        if(val>1){
            --val;
            $input.val(val);
            dis($input);
        }
    });
});

function updateCartNum(){
    //���¹��ﳵ����
    var $cartNum = $(".j-cartnum");
    $.ajax({
        type:"GET",
        url:"data/cart/getCartNum.php",
        data:{uid:localStorage.getItem('wyUserId')},
        success:function (cartNum){
            if(cartNum!=""){
                $cartNum.html(cartNum);
            }else{
                $cartNum.html(0);
            }
        }
    });
}