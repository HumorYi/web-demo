$(function(){
    var unameSwitch=false;
    var upwdSwitch=false;
    var cpwdSwitch=false;
    var phoneSwitch=false;
    var emailSwitch=false;

    //用户名验证
    $('#uname').focus(function(){
        $(this).siblings('span').fadeIn(600);
        if($(this).val().length===0)unameSwitch=false;
    }).on('keyup',this,function(){
        if($(this).val().length<=0) return false;
        if(/^[\w\u4e00-\u9fa5]{2,20}$/.test($(this).val())){
            $(this).siblings('span').html('用户名正确').attr('class','success');
            unameSwitch=true;
        }else{
            $(this).siblings('span').html('用户名不符合规则').attr('class','warning');
            unameSwitch=false;
        }
    }).blur(function(){
        var _this=$(this);
        if(unameSwitch===true){
            $.ajax({
                type:'get',
                url:'data/users/isUname.php',
                data:{uname:$(this).val()},
                dataType:'json',
                success:function(data){
                    if(data.code>0){
                        _this.siblings('span').html(data.msg).attr('class','success');
                        unameSwitch=true;
                    }else{
                        _this.siblings('span').html(data.msg).attr('class','warning');
                        unameSwitch=false;
                    }
                },
                error(){
                    alert('网络错误请检查!');
                }
            })
        }else{
            $(this).siblings('span').html('用户名不符合规则').attr('class','warning')
        }
    });

    //密码验证
    var upwd='';
    $('#upwd').focus(function(){
        $(this).siblings('span').fadeIn(600);
        if($(this).val().length===0)upwdSwitch=false;
    }).on('keyup',this,function(){
        if($(this).val().length<=0) return false;
        if(/^[\w]{6,20}$/.test($(this).val())){
            $(this).siblings('span').attr('class','success');
            upwdSwitch=true;
        }else{
            $(this).siblings('span').attr('class','warning');
            if(upwdSwitch>0)upwdSwitch=false;
        }
    }).blur(function(){
        if(upwdSwitch===true){
            $(this).siblings('span').html('密码可以使用').attr('class','success');
            upwd=$(this).val();
        }else{
            $(this).siblings('span').html('密码不符合规则').attr('class','warning')
        }
    });

    //确认密码
    $('#cpwd').focus(function(){
        $(this).siblings('span').fadeIn(600)
    }).on('keyup',this,function(){
        if(/^[\w]{6,20}$/.test($(this).val())){
            if($(this).val()===upwd){
                $(this).siblings('span').html('密码一致,请妥善保存密码');
                $(this).siblings('span').attr('class','success');
                cpwdSwitch=true;
            }else{
                $(this).siblings('span').html('密码不一致,请重新输入');
                $(this).siblings('span').attr('class','warning');
                cpwdSwitch=false;
            }
        }else{
            $(this).siblings('span').html('密码不符合规则').attr('class','warning');
            cpwdSwitch=false;
        }
    }).blur(function(){
        cpwdSwitch===true?$(this).siblings('span').html('密码一致,请妥善保存密码').attr('class','success'):$(this).siblings('span').html('密码不符合规则').attr('class','warning')
    });

    //邮箱验证
    $("#email").focus(function (){
        $(this).siblings('span').fadeIn(600);
        if($(this).val().length===0){
            emailSwitch = false;
        }
    }).on('keyup',this,function(){
        if($(this).val().length<=0) return false;
        if(/^[A-Za-z0-9\u4e00-\u9fa5]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/.test($(this).val())){
            $(this).siblings('span').attr('class','success');
            emailSwitch=true;
        }else{
            $(this).siblings('span').attr('class','warning');
            if(emailSwitch>0)emailSwitch=false;
        }
    }).blur(function(){
        if(emailSwitch===true){
            $(this).siblings('span').html('邮箱可以使用').attr('class','success');
            upwd=$(this).val();
        }else{
            $(this).siblings('span').html('邮箱不符合规则').attr('class','warning')
        }
    });

    //手机号验证
    $('#phone').focus(function(){
        $(this).siblings('span').fadeIn(600);
        if($(this).val().length===0){
            phoneSwitch = false;
        }
    }).on('keyup',this,function(){
        if($(this).val().length<=0) return false;
        if(/^[1][3,4,5,7,8][0-9]{9}$/.test($(this).val())){
            $(this).siblings('span').attr('class','success');
            phoneSwitch=true;
        }else{
            $(this).siblings('span').attr('class','warning');
            phoneSwitch=false;
        }
    }).blur(function(){
        var _this=$(this);
        if(phoneSwitch===true){
            $.ajax({
                type:'get',
                url:'data/users/isphone.php',
                data:{phone:$(this).val()},
                dataType:'json',
                success:function(data){
                    if(data.code>0){
                        _this.siblings('span').html(data.msg).attr('class','success');
                        phoneSwitch=true;
                    }else{
                        _this.siblings('span').html(data.msg).attr('class','warning');
                        phoneSwitch=false;
                    }
                },
                error(){
                    alert('网络错误请检查!');
                }
            });
            $(this).siblings('span').html('手机号可用').attr('class','success');
        }else{
            $(this).siblings('span').html('手机号不符合规则').attr('class','warning');
        }
    });

    //点击注册按钮
    $('#reg>.content>form .reg_but').click(function(){
        $('#reg>form').submit();
        if(unameSwitch===true && upwdSwitch===true && cpwdSwitch===true && phoneSwitch===true && emailSwitch===true){
            $.ajax({
                type:'post',
                url:'data/users/register.php',
                dataType:'json',
                data:$('#register').serialize(),
                success(data){
                   if(data.code>0){
                       alert('注册成功');
                       location.replace('login.html');
                   }else{
                       alert('注册失败');
                   }
                },
                error(){
                    alert('网络错误请检查');
                }
            })
        }else{
            alert('你填写的信息不完整');

        }
    })
});