function allBehavior(){

    //放大镜
    var meng = document.getElementById('smallmask');
    var minbox = document.getElementById('imgBox');
    var maxbox = document.getElementById('bigimgBox');
    var maximg = maxbox.getElementsByTagName('img')[0];
    var minimg = minbox.getElementsByTagName('img')[0];

    function offsetTL(obj){
        var ofL = 0,ofT = 0;
        while(obj){
            ofL += obj.offsetLeft + obj.clientLeft;
            ofT += obj.offsetTop + obj.clientTop;
            obj = obj.offsetParent;
        }
        return {
            left : ofL,
            top : ofT
        };
    }

    minbox.onmousemove = function(e){
        var e = e || event;
        meng.style.display = 'block';
        maxbox.style.display = 'block';
        var mengX = e.pageX - offsetTL(minbox).left - meng.clientWidth/2;    //蒙板的X坐标
        var mengY = e.pageY - offsetTL(minbox).top - meng.clientHeight/2;    //蒙板的Y坐标
        var bili = maximg.clientWidth/minimg.clientWidth;
        if (mengX <= 0) {
            mengX = 0;
        }else if (mengX >= minbox.clientWidth - meng.clientWidth) {
            mengX = minbox.clientWidth - meng.clientWidth;
        }if (mengY <= 0) {
            mengY=0;
        }else if (mengY >= minbox.clientHeight - meng.clientHeight) {
            mengY = minbox.clientHeight - meng.clientHeight;
        }
//        console.log("X:",mengX);
//        console.log("Y:",mengY);
        meng.style.left = mengX + 'px';
        meng.style.top = mengY + 'px';
        maximg.style.left = -parseInt(meng.style.left)*bili + 'px';
        maximg.style.top = -parseInt(meng.style.top)*bili + 'px';
    };

    minbox.onmouseout = function(){
        meng.style.display = 'none';
        maxbox.style.display = 'none';
    };

    //点击小图片切换对应img
    var $smnavs = $(".smnav>ul>li");
    var $smnav_ul = $(".smnav>ul");
    var activeIndex = 1;
    var lastIndex = $smnavs.size();
    var beforeIndex = 1;
    var imgWidth = 90;
    var startLeft = 0;
    var endLeft = -270;
    var prevLeft = parseInt($smnav_ul.css("left"));

    //图片切换行为函数
    function move(){
        var imgBoxIndex = minimg.src.slice(-5);
        var bigimgBoxIndex = maximg.src.slice(-5);
        var nowSrc = minimg.src.replace(imgBoxIndex, activeIndex + ".jpg");
        var nowBigSrc = maximg.src.replace(bigimgBoxIndex, activeIndex + ".png");
        minimg.src = nowSrc;
        maximg.src = nowBigSrc;
        $smnavs.eq(activeIndex-1).addClass("z-sel").siblings().removeClass("z-sel");
    }

    // 小图移动方法
    function imgMove(currIndex) {
        if (activeIndex === currIndex) {
            return;
        }

        beforeIndex = activeIndex;
        activeIndex = currIndex;
        move();

        if (activeIndex < 4 && prevLeft >= startLeft
            || 
            activeIndex > lastIndex - 1 && prevLeft <= endLeft
        ) {
            return;
        }

        if (activeIndex >= 2 && activeIndex <= lastIndex - 1) {
            if (activeIndex >= lastIndex - 2 && prevLeft <= endLeft) {
                return;
            }
            
            if (activeIndex > beforeIndex) {
                prevLeft -= imgWidth;
            }else {
                prevLeft += imgWidth;
            }
            
            $smnav_ul.css("left", prevLeft);
        }
    }

        //小图片点击
    $smnavs.click(function () {
        var currIndex = $(this).index() + 1;
        imgMove(currIndex);
    });

    //图片左右按钮
    var $pic = $(".pic");
    var $arrowLeft = $(".arrowleft");
    var $arrowRight = $(".arrowright");

    //显示左右按钮函数
    function showArrowBtn(){
        if(activeIndex>1){
            $arrowLeft.show();
        }
        else if(activeIndex<=1){
            $arrowLeft.hide();
        }
        
        if(activeIndex<lastIndex){
            $arrowRight.show();
        }
        else if(activeIndex>=lastIndex){
            $arrowRight.hide();
        }
    }

    $pic.mousemove(function (){
        showArrowBtn();
    }).mouseout(function (){
        $arrowLeft.hide();
        $arrowRight.hide();
    });

    //左按钮点击
    $arrowLeft.click(function (){
        imgMove(activeIndex - 1);        
        showArrowBtn();
    });

    //右按钮点击
    $arrowRight.click(function (){
        imgMove(activeIndex + 1);
        showArrowBtn();
    });

    //右侧导航
    var $gtab=$(".n-content");
    var $mback=$(".m-back");
    $(window).scroll(function (){
        var scrollTop=$(window).scrollTop();
        if($gtab.offset().top<scrollTop+innerHeight/3){
            $mback.show();
        }else{
            $mback.hide();
        }
    });

    //头部悬浮固定导航
    var $topbar = $("#j-topbar");
    $(window).scroll(function (){
        var scrollTop=$(window).scrollTop();
        if($gtab.offset().top<scrollTop+innerHeight/2){
            $topbar.addClass("show");
        }else{
            $topbar.removeClass("show");
        }
    });

    //商品颜色选择
    $(".select ul>li").click(function (){
        $(this).addClass("show").siblings().removeClass("show");
        activeIndex = $(this).attr("data-color");
        move();
    });

    //优惠券 Hover
    $("#coupon-list").mousemove(function (){
        $(this).addClass("show-all");
        $("#coupon-arr").addClass("up");
    });
    $("#coupon-list").mouseout(function (){
        $(this).removeClass("show-all");
        $("#coupon-arr").removeClass("up");
    });

    //加入购物车动画
    function addShoppingCartAnimate(){
        var img = $("#imgBox").find('img');
        var flyImg = img.clone().css({
            'opacity':'0.8'
        });
        $('body').append(flyImg);
        flyImg.css({
            'z-index':999,
            //'border':'3px solid #fff',
            'position': 'absolute',
            'height' : img.height() + 'px',
            'width' : img.width() + 'px',
            'top' : img.offset().top +'px',
            'left' : img.offset().left + 'px'
        });
        flyImg.animate({
            'width' : 200 + 'px',
            'height' : 200 + 'px'
            //'border-radius' : 100 + '%'
        },400,function(){
            var t = $('.j-cartnumRight').offset().top;
            var l = $('.m-wrap').offset().left;
            flyImg.animate({
                'top':t,
                //'left':($(document).width()-$('.m-wrap').width()) + 'px',
                'left':l,
                'height':20 +'px',
                'width' :20+'px'
            },1000,function(){
                //console.log($(document));
                flyImg.remove();
            })
        });
    }

        //加入购物车按钮
    $('.addShopart').on('click',function () {
        addShoppingCartAnimate();
        //判断用户是否登录
        if(localStorage.getItem('wyUserId')){
            var wyUserId = localStorage.getItem('wyUserId');
            var productId = activeIndex;
            var counts = parseInt($(".text").val());
            $.ajax({
                type:"POST",
                url:"data/cart/addCart.php",
                data:{uid:wyUserId,did:productId,count:counts},
                success:function (res){
                    console.log("已进入ajax");
                    console.log("用户ID",wyUserId);
                    console.log("商品ID",productId);
                    console.log("购买数量",counts);
                    console.log(res);

                    //更新购物车数量
                    updateCartNum();
                },
                error:function (){
                    alert("网络故障请检查！");
                }
            })
        }else{
            alert("请先登录！");
            location.replace('login.html');
        }

    });

    //点击服务弹出框
    $("div[data-action='showService']>a").click(function (){
        var html = `
            <div class="m-layer">
                <div class="zbar">
                    <div class="zttl">服务</div>
                </div>
                <div class="zcnt">
                    <div class="service-layer">
                        <div class="cnt">
                            <h5 class="service">不支持7天无理由退货</h5>
                            <p>该商品不支持7天无理由退货</p>
                            <h5 class="service">商家发货</h5>
                            <p>该商品由上海微意电子有限公司发货，2个工作日内发货，法定节假日顺延。（本商品2月5日-25日暂停发货）</p>
                            <h5 class="service">商家认证</h5>
                            <p>严格审核商家资质，100%正规渠道商品</p>
                        </div>
                        <div class="f-tc footer">
                            <a class="u-btn-new u-btn-new2 iKnow">知道了</a>
                        </div>
                    </div>
                </div>
                <span class="zcls" title="关闭窗口">×</span>
            </div>`;
        $('body').append(html);
        $("body").on("click",".zcls",function (){
            $(this).parent().remove();
        });
        $("body").on("click",".iKnow",function (){
            $(this).parents(".m-layer").remove();
        });
    });

}

$(function (){
    //下方小图片
    var $smnavUls = $(".smnav>ul.j-flag");
    //颜色选择
    var $colorSelect = $(".select-time ul");

    $.ajax({
        type:"GET",
        url:"data/products/product_details.php",
        dataType:"JSON",
        success:function (products){
            var html = "";
            var colorHtml = "";
            for(var res of products){
                html += `
                <li>
                    <img src="${res.min_img}" alt=""/>
                </li>`;

                colorHtml +=`<li data-color="${res.did}">${res.color_title}</li>`;
            }
            $smnavUls.html(html).children('li:first-child').addClass("z-sel");
            $colorSelect.html(colorHtml);

            allBehavior();
        }
    });
});