//轮播
$(function () {

    //轮播图
    var $banner = $("#n-banner");
    var $banner_uls = $banner.find("ul");
    var $dots = $(".dots");
    var activeIndex = 0;
    var timer = null;
    var $banner_imgs = null;
    var $banner_dots = null;
    var lastIndex = 0;

    //轮播移动
    function move() {
        activeIndex = activeIndex || 0;

        if (activeIndex > lastIndex) {
            activeIndex = 0;
        }else if (activeIndex < 0) {
            activeIndex = lastIndex;
        }
        $banner_imgs.eq(activeIndex).fadeIn().siblings().fadeOut();
        $banner_dots.eq(activeIndex).addClass("active").siblings().removeClass("active");
    }

    //自动轮播
    function autoplay() {
        timer = setInterval(function() {
            ++activeIndex;
            move(activeIndex);
        }, 3000);
    }

    //移动方向
    function directionMove() {
        timer && clearInterval(timer);
        move();
        autoplay()
    }

    $.ajax({
        type:"GET",
        url:"data/index/getCarousel.php",
        dataType:"JSON",
        success:function (products){
            var html = "";
            for(var {bg_color,img} of products){
                html += `
                    <li class="f-pa" style="${bg_color}">
                        <a href="#" class="f-pa">
                            <img src="${img}">
                        </a>
                    </li>`;
            }
            /*//左右轮播的无缝拼接
            html += `
                <li class="f-pa" style="${products[0].bgColor}">
                  <a href="#" class="f-pa">
                    <img src="${products[0].img}">
                  </a>
                </li>`;*/
            $banner_uls.html(html);
            //根据轮播图数量长度动态添加小圆点
            $dots.html("<span></span>".repeat(products.length));

            $banner_imgs = $banner.find("ul.imgs>li");
            $banner_dots = $banner.find(".dots>span");
            lastIndex = $banner_imgs.size() - 1;

            directionMove();

            //轮播左右按钮
            $(".point a.left").click(function(){
                --activeIndex;
                directionMove();
            });
            $(".point a.right").click(function(){
                ++activeIndex;
                directionMove();
            });
            //轮播小圆点
            $banner_dots.on("click",function (){
                activeIndex = $(this).index();
                directionMove();
            });
            //暂停轮播
            $banner.mouseenter(function (){
                clearInterval(timer);
            });
            //鼠标离开继续轮播
            $banner.mouseout(function (){
                directionMove();
            });
        }
    });

    //右侧导航
    var $gtab=$(".g-tab");
    var $mtop=$("#m-top");
    $(window).scroll(function (){
        var scrollTop=$(window).scrollTop();
        if($gtab.offset().top<scrollTop+innerHeight/3){
            $mtop.show();
        }else{
            $mtop.hide();
        }
    });
});

$(function (){
    var $productListRecommend = $(".m-product>ul.recommend");
    var $productListHor = $(".m-product>ul.hot");

    $.ajax({
        type:"GET",
        url:"data/index/getProducts.php",
        dataType:"JSON",
        success:function (products){
            var html = "";
            var htmlHot = "";
            products.forEach((p,index)=>{
                var {details,pic,href,price,original_price} = p;
                //编辑推荐
                if(index<4){
                    html += `
                        <li>
                            <div>
                                <a href="${href}" class="cover f-pr f-blk j-statistics">
                                    <img src="${pic}" class="f-img">
                                    <span class="spec f-pa">
                                        <span class="origin f-pa">¥${price}</span>
                                        <span class="cut f-pa">
                                            <del>¥${original_price}</del>
                                        </span>
                                    </span>
                                </a>
                                <div class="cnt f-tc">
                                    <h3 class="f-thide2">
                                        <span class="tag tag-red">
                                            <em>特价</em>
                                        </span>
                                        <a href="${href}">${details}</a>
                                    </h3>
                                    <p class="txt f-thide">
                                        ¥<em>${price}</em>
                                    </p>
                                </div>
                            </div>
                        </li>`;
                    $productListRecommend.html(html+html);
                }
                //热门商品
                if(index>=4){
                    htmlHot += `
                        <li>
                            <div>
                                <a href="${href}" class="cover f-pr f-blk j-statistics">
                                    <img class="f-img j-lazy z-loaded" src="${pic}" alt="">
                                </a>
                                <div class="cnt f-tc">
                                    <h3 class="f-thide2">
                                        <span class="tag tag-red">
                                            <em>热门</em>
                                        </span>
                                        <a href="${href}">${details}</a>
                                    </h3>
                                    <p class="txt f-thide">
                                        ¥<em>${price}</em>
                                    </p>
                                </div>
                            </div>
                        </li>`;
                }
                //var htmlHots = htmlHot*5;
                $productListHor.html(htmlHot+htmlHot+htmlHot+htmlHot+htmlHot);
            });
        }
    })
});
