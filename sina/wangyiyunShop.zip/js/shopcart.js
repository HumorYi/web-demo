$(function (){
    //登录判断
    var $shopHead = $(".n-cart div.head");
    var $shoppingList = $(".n-cart ul.shoppingList");
    if(!localStorage.getItem('wyUserName')){
        $shopHead.hide();
        $shoppingList.hide();
    }
    
    //右侧导航
    var $midBorder=$(".mid-border");
    var $mback=$(".m-back");
    $(window).scroll(function (){
        var scrollTop=$(window).scrollTop();
        if($midBorder.offset().top<scrollTop+innerHeight/4){
            $mback.show();
        }else{
            $mback.hide();
        }
    });

    //热门推荐
    var $productList = $(".m-product>ul.list");
    $.ajax({
        type:"GET",
        url:"data/index/getProducts.php",
        dataType:"JSON",
        success:function (products){
            var html = "";
            products.forEach((p,index)=>{
                var {details,pic,href,price,original_price} = p;
                if(index<4){
                    html += `
                    <li>
                        <div>
                            <a href="${href}" class="cover f-pr f-blk j-statistics">
                                <img src="${pic}" alt="" class="f-img">
                                    <span class="spec f-pa">
                                        <span class="origin f-pa">¥${price}</span>
                                        <span class="cut f-pa">
                                            <del>¥${original_price}</del>
                                        </span>
                                    </span>
                            </a>
                            <div class="cnt f-tc">
                                <h3 class="f-thide2">
                                        <span class="tag tag-red">
                                            <em>特价</em>
                                        </span>
                                    <a href="${href}">${details}</a>
                                </h3>
                                <p class="txt f-thide">
                                    ¥<em>${price}</em>
                                </p>
                            </div>
                        </div>
                    </li>`;
                }
                $productList.html(html+html);
            })
        }
    });

    //全选按钮
    var $checkAll = $(".n-cart div.check>i.checkboxAll");
    var $mr = $("#module-root");

    //ajax访问数据库加载页面
    function load(){
        var $total = $(".total em");
        $.ajax({
            type:"GET",
            url:"data/cart/getCart.php",
            data:{uid:localStorage.getItem('wyUserId')},
            dataType: "json",
            success:function (res){
                //初始化购买数量
                var sum = 0;
                //初始化总价
                var total = 0;
                //初始化全选按钮
                var countIsChecked = 0;

                //shoppingHeader
                var html = `
                <li class="f-cb s-fc4 first">
                    <div class="f-fl product">
                        全部商品&nbsp;(&nbsp;<span class="selected">${sum}</span>&nbsp;)&nbsp;
                    </div>
                    <div class="f-fr f-mgr20">
                        <div class="f-fl icon">
                            <i></i>
                        </div>
                        <div class="f-fl txt s-fc333">
                            全场满
                            <em style="color: #d33a31;">¥119</em>
                            免运费
                        </div>
                    </div>
                </li>`;

                //shoppingList
                for(var {cart_id,is_checked,min_img,title,color_title,price,count} of res){
                    if (is_checked === "1") {
                        ++countIsChecked;
                    }

                    if(is_checked == 1){
                        sum += parseInt(count);
                        total += price*count;
                    }

                    //判断购买数量"-"按钮样式
                    var decrementActive = count > 1 ? "" : "btn-dis";
                    //判断复选框勾选按钮样式
                    var isCheckedClass = is_checked === "1" ? " z-checked" : "";
                    html += `
                    <li class="f-cb" data-cartid=${cart_id}>
                        <div class="check f-fl">
                            <i class="checkbox u-checkbox ${isCheckedClass}" data-check="checkbox"></i>
                        </div>
                        <div class="cnt f-fl">
                            <div class="coverwrap f-fl">
                                <div class="cover">
                                    <a href="product_details.html">
                                        <img src="${min_img}" alt=""/>
                                    </a>
                                </div>
                            </div>
                            <div class="msg f-fl">
                                <a href="product_details.html">
                                    <p class="tit f-thide">${title}</p>
                                </a>
                                <p class="sku s-fc4 f-thide">${color_title}</p>
                            </div>
                            <div class="price f-fl f-tc">
                                ¥<em>${price}</em>
                            </div>
                            <div class="ctrl f-fl f-pr f-tc">
                                <div class="u-counter f-fl number">
                                    <a href="javascript:void(0);" class="btn ${decrementActive}">
                                        <i class="u-icn u-icn-27 reduce"></i>
                                    </a>
                                    <span class="tot">
                                        <input type="text" class="text" value="${count}">
                                    </span>
                                    <a href="javascript:void(0);" class="btn">
                                        <i class="u-icn u-icn-28 add"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="price line f-fl f-tc">
                                ¥${(price*count)}
                            </div>
                            <div class="delete f-fl"></div>
                        </div>
                    </li>`;
                }

                //shoppingFooter
                //判断全选按钮样式
                var isCheckAll = countIsChecked=== res.length ? "z-checked" : "";
                html += `
                <li class="bottom" id="bottom" style="position: static;z-index: 1;bottom: 0;">
                    <div class="f-cb s-fc4">
                        <div class="check f-fl">
                            <i class="checkbox u-checkbox ${isCheckAll} checkboxAll"></i>
                        </div>
                        <div class="f-fl">
                            <div class="coverwrap f-fl s-fc333">全选</div>
                            <div class="product f-fl">
                                已选择<em style="color: #d33a31;" class="selected">${sum}</em>件商品
                            </div>
                        </div>
                        <div class="paybtn f-fr">结算</div>
                        <div class="f-fr">
                            <span class="s-fc4">满¥119免运费&nbsp;|&nbsp;</span>
                            <span class="s-fc1">合计&nbsp;:&nbsp;</span>
                            <span class="total">
                                ¥<em>${total}</em>
                            </span>
                        </div>
                    </div>
                </li>`;

                $shoppingList.html(html).find(".selected").html(sum);
                $total.html(total);

                //全选按钮判断
                if (countIsChecked === res.length) {
                    $checkAll.addClass("z-checked");
                }else {
                    $checkAll.removeClass("z-checked");
                }

                //购物车是否为空显示不同部分页面
                 var $empty = $(".n-cart div.empty");

                 if(res.length == 0){
                     $empty.show();
                     $shopHead.hide();
                     $shoppingList.hide();
                 }else{
                     $empty.hide();
                     $shopHead.show();
                     $shoppingList.show();
                 }
            }
        });
    }
    load();

    //shoppingCartList按钮事件
    $shoppingList.on("click",".add, .reduce, [data-check=checkbox], .delete",function (e){
        var cart_id = 0;
        var $tar=$(this);

        //添加"+",减少"-"购买数量按钮
        if ($tar.is(".add,.reduce")) {
            cart_id = $tar.parent().parent().parent().parent().parent().attr("data-cartid");
            var count = parseInt($tar.parent().siblings("span.tot").find(".text").val());
            $tar.is(".add") ? count++ : count--;
            $.ajax({
                type: "GET",
                url: "data/cart/updateCart.php",
                data: {cart_id, count},
                success: function () {
                    load();
                    updateCartNum();
                }
            })
        }
        //复选框勾选按钮
        else if($tar.is("[data-check=checkbox]")){
            cart_id = $tar.parent().parent().attr("data-cartid");
            var checked = 1;
            if($tar.hasClass("z-checked")){
                $tar.removeClass("z-checked");
                checked = 0;
            }else{
                $tar.addClass("z-checked");
                checked = 1;
            }
            $.ajax({
                type:"get",
                url:"data/cart/check.php",
                data:{cart_id,checked},
                success:function (){
                    load();
                    updateCartNum();
                }
            })
        }
        //删除"×"按钮
        else{
            e.preventDefault();
            cart_id = $tar.parent().parent().attr("data-cartid");
            if(confirm("是否继续删除当前商品?")){
                $.ajax({
                    type:"get",
                    url:"data/cart/delete.php",
                    data:{cart_id},
                    success:function (){
                        load();
                        updateCartNum();
                    }
                })
            }
        }
    });

    //全选按钮点击事件
    $mr.on("click",".checkboxAll",function (){
        var $check=$(this);
        var checked = 1;
        if($check.hasClass("z-checked")){
            $checkAll.removeClass("z-checked");
            $check.removeClass("z-checked");
            checked = 0;
        }else{
            $checkAll.addClass("z-checked");
            $check.addClass("z-checked");
            checked = 1;
        }
        $.ajax({
            type:"get",
            url:"data/cart/checkAll.php",
            data:{uid:localStorage.getItem('wyUserId'),checked},
            success:function (){
                load();
            }
        })
    });

});

