$(function (){
    //放大镜
    //var $meng = $("#smallmask");
    //var $minbox = $("#imgBox");
    //var $maxbox = $("#bigimgBox");
    //var $maximg = $("#bigimgBox img");
    //var $minimg = $("#imgBox img");

    var meng = document.getElementById('smallmask');
    var minbox = document.getElementById('imgBox');
    var maxbox = document.getElementById('bigimgBox');
    var maximg = maxbox.getElementsByTagName('img')[0];
    var minimg = minbox.getElementsByTagName('img')[0];

    function offsetTL(obj){
        var ofL = 0,ofT = 0;
        while(obj){
            ofL += obj.offsetLeft + obj.clientLeft;
            ofT += obj.offsetTop + obj.clientTop;
            obj = obj.offsetParent;
        }
        return {
            left : ofL,
            top : ofT
        };
    }

    /*var minBoxWidth = minbox.clientWidth;
    var minBoxHeight = minbox.clientHeight;
    minbox.onmousemove = function(e){
        var e = e || event;

        if (meng.style.display === "none") {
            meng.style.display = 'block';
            maxbox.style.display = 'block';
        }

        var mengWidth = meng.clientWidth;
        var mengHeight = meng.clientHeight;
        var bili = maxbox.clientWidth/minBoxWidth;

        /!*var mengX = e.clientX - offsetTL(minbox).left-meng.clientWidth/2;  //遮罩层的X坐标
        var mengY = e.clientY - offsetTL(minbox).top-meng.clientHeight/2;  //遮罩层的Y坐标
        *!/
        var left = e.clientX - minbox.offsetLeft - meng.offsetLeft - mengWidth/2;  //遮罩层的X坐标
        var top = e.clientY  - minbox.offsetTop - meng.offsetTop - mengHeight/2;  //遮罩层的Y坐标
        console.log(e.clientY);
        console.log("start S");
        console.log(left);
        console.log(top);
        console.log("start E");
        if(left <= 0){
            left = 0;
        }else if(left >= minBoxWidth - mengWidth){
            left = minBoxWidth-mengWidth;
        }

        if(top <= 0){
            top = 0;
        }else if(top >= minBoxHeight - mengHeight){
            top = minBoxHeight - mengHeight;
        }
        console.log("end S");
        console.log(left);
        console.log(top);
        console.log("end E");*/

    minbox.onmousemove = function(e){
        var e = e || event;
        meng.style.display = 'block';
        maxbox.style.display = 'block';
        var mengX = e.clientX - offsetTL(minbox).left - meng.clientWidth/2;    //蒙板的X坐标
        var mengY = e.clientY - offsetTL(minbox).top - meng.clientHeight/2;    //蒙板的Y坐标
        var bili = maximg.clientWidth/minimg.clientWidth;
        if (mengX <= 0) {
            mengX = 0;
        }else if (mengX >= minbox.clientWidth - meng.clientWidth) {
            mengX = minbox.clientWidth - meng.clientWidth;
        }if (mengY <= 0) {
            mengY=0;
        }else if (mengY >= minbox.clientHeight - meng.clientHeight) {
            mengY = minbox.clientHeight - meng.clientHeight;
        }
        //console.log(mengX);
        //console.log(mengY);
        meng.style.left = mengX + 'px';
        meng.style.top = mengY + 'px';
        maximg.style.left = -parseInt(meng.style.left)*bili + 'px';
        maximg.style.top = -parseInt(meng.style.top)*bili + 'px';
        };
        minbox.onmouseout = function(){
            meng.style.display = 'none';
            maxbox.style.display = 'none';
        };

    //小图片切换行为函数
    function move(){
        var imgBoxIndex = minimg.src.slice(-5);
        var bigimgBoxIndex = maximg.src.slice(-5);
        var nowSrc = minimg.src.replace(imgBoxIndex, activeIndex + ".jpg");
        var nowBigSrc = maximg.src.replace(bigimgBoxIndex, activeIndex + ".png");
        minimg.src = nowSrc;
        maximg.src = nowBigSrc;
        $smnavs.eq(activeIndex-1).addClass("z-sel").siblings().removeClass("z-sel");
    }

    //点击小图片切换对应img
    var $smnavs = $(".smnav>ul>li");
    var activeIndex = 0;
    var lastIndex = $smnavs.size();
    var moveIndex = 0;

    $smnavs.click(function (){
        activeIndex = $(this).index()+1;
        move(activeIndex);
        $(this).addClass("z-sel").siblings().removeClass("z-sel");
        if(activeIndex>3 && activeIndex<=6){
            moveIndex++;
            $(".smnav>ul").css("left",-90*moveIndex);
            console.log("当前:",activeIndex);
        }else{
            moveIndex--;
            console.log("进入了else");
            $(".smnav>ul").css("left",90*moveIndex);
        }
    });

    //按钮切换图片行为函数
    function showArrowBtn(){
        if(activeIndex>1){
            $arrowLeft.show();
        }
        if(activeIndex<lastIndex){
            $arrowRight.show();
        }
        if(activeIndex>=lastIndex){
            $arrowRight.hide();
        }
    }

    //图片左右按钮
    var $pic = $(".pic");
    var $arrowLeft = $(".arrowleft");
    var $arrowRight = $(".arrowright");

    $pic.mousemove(function (){
        showArrowBtn();
    }).mouseout(function (){
        $arrowLeft.hide();
        $arrowRight.hide();
    });

    $arrowLeft.click(function (){
        if(activeIndex>1){
            activeIndex--;
            move(activeIndex);
        }
        showArrowBtn();
    });

    activeIndex = 1;
    $arrowRight.click(function (){
        if(activeIndex<lastIndex){
            ++activeIndex;
            move(activeIndex);
            showArrowBtn();
        }
    });

    //右侧导航
    var $gtab=$(".n-content");
    var $mback=$(".m-back");
    $(window).scroll(function (){
        var scrollTop=$(window).scrollTop();
        if($gtab.offset().top<scrollTop+innerHeight/3){
            $mback.show();
        }else{
            $mback.hide();
        }
    });

    //头部悬浮固定导航
    var $topbar = $("#j-topbar");
    $(window).scroll(function (){
        var scrollTop=$(window).scrollTop();
        if($gtab.offset().top<scrollTop+innerHeight/2){
            $topbar.addClass("show");
        }else{
            $topbar.removeClass("show");
        }
    });

    //购物车数量添加
    var $reduce = $(".u-icn-27");
    var $num = $(".text");
    var $numVal = $(".text").val();
    var $add = $(".u-icn-28");

    //购物车按钮样式
    function dis(){
        if($numVal>1){
            $(".u-counter>a.btn").removeClass("btn-dis");
        }else{
            $(".u-counter>:first-child.btn").addClass("btn-dis");
        }
    }

    $add.click(function (){
        $numVal++;
        $num.val($numVal);
        dis();
    });
    $reduce.click(function (){
        if($numVal>1){
            $numVal--;
            $num.val($numVal);
            dis();
        }
    });

    //商品颜色选择
    $(".select ul>li").click(function (){
        $(this).addClass("show").siblings().removeClass("show");
    })

    //优惠券 Hover
    $("#coupon-list").mousemove(function (){
        $(this).addClass("show-all");
        $("#coupon-arr").addClass("up");
    });
    $("#coupon-list").mouseout(function (){
        $(this).removeClass("show-all");
        $("#coupon-arr").removeClass("up");
    });

    //加入购物车动画
    function clickBtn() {
        $('.addShopart').on('click',function () {
            var img = $("#imgBox").find('img');
            var flyImg = img.clone().css({
                'opacity':'0.8'
            });
            $('#add').append(flyImg);
            flyImg.css({
                'z-index':999,
                //'border':'3px solid #fff',
                'position': 'absolute',
                'height' : img.height() + 'px',
                'width' : img.width() + 'px',
                'top' : img.offset().top +'px',
                'left' : img.offset().left + 'px'
            });
            flyImg.animate({
                'width' : 200 + 'px',
                'height' : 200 + 'px'
                //'border-radius' : 100 + '%'
            },400,function(){
                var t = $('.j-cartnum').offset().top;
                flyImg.animate({
                    'top':t,
                    'left':($(document).width()-$('.m-wrap').width()) + 'px',
                    'height':20 +'px',
                    'width' :20+'px'
                },1000,function(){
                    flyImg.remove();
                })
            });
        })
    }
    clickBtn();
});