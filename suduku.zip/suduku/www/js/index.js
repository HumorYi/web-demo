/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var toolkit = __webpack_require__(1);

var Grid = function () {
    function Grid(container) {
        _classCallCheck(this, Grid);

        this._$container = container;
    }

    _createClass(Grid, [{
        key: "build",
        value: function build() {
            var matrix = toolkit.makeMatrix();

            var rowGroupClasses = ["row_g_top", "row_g_middle", "row_g_bottom"];
            var colGroupClasses = ["col_g_left", "col_g_center", "col_g_right"];

            // 为矩阵中每列添加一个 span标签
            var $cells = matrix.map(function (rowValues) {
                return rowValues.map(function (cellValue, colIndex) {
                    return $("<span>").addClass(colGroupClasses[colIndex % 3]).text(cellValue);
                });
            });

            // 为矩阵中的每行添加一个 div标签
            var $divArray = $cells.map(function ($spanArray, rowIndex) {
                return $("<div>").addClass("row").addClass(rowGroupClasses[rowIndex % 3]).append($spanArray);
            });

            // 把矩阵添加到面板中去
            this._$container.append($divArray);
        }

        // 布局表格大小

    }, {
        key: "layout",
        value: function layout() {
            var width = $("span:first", this._$container).width();

            $("span", this._$container).height(width).css({
                "line-height": width + "px",
                "font-size": width < 32 ? width / 2 + "px" : ""
            });
        }
    }]);

    return Grid;
}();

var grid = new Grid($("#container"));
grid.build();
grid.layout();

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var matrixToolkit = {
    rowLen: 9,
    cellLen: 9,

    // 制作行数组
    makeRow: function makeRow() {
        var v = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;

        var array = new Array(matrixToolkit.cellLen);
        // 把array中的每个值都赋值为 v
        array.fill(v);

        return array;
    },


    // 制作矩阵数组
    makeMatrix: function makeMatrix() {
        var v = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;

        /**
         * 网址：https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Array/from
         * Array.from() 方法从一个类似数组或可迭代对象中创建一个新的数组实例。
         * Array.from(arrayLike, mapFn, thisArg)
         参数
         arrayLike
         想要转换成数组的伪数组对象或可迭代对象。
         mapFn (可选参数)
         如果指定了该参数，新数组中的每个元素会执行该回调函数。
         thisArg (可选参数)
         可选参数，执行回调函数 mapFn 时 this 对象。
         返回值
         一个新的数组实例
           { length: rowLen } === new Array(rowLen)
         */
        return Array.from({ length: matrixToolkit.rowLen }, function () {
            return matrixToolkit.makeRow(v);
        });
    },


    /**
     * Fisher-Yetes 算法
     * 随机置乱算法也被称做高纳德置乱算法,通俗说就是生成一个有限集合的随机排列
     *
     * 从0位置开始，在当前列随机找一个值与当前元素值，如果与当前值相等，则不替换，否则互换双方的值
     * --> 直到导数第二行，最后一行是不需要比较的
     */
    shuffle: function shuffle(array) {
        var arrLen = array.length;
        var endIndex = arrLen - 2;
        for (var i = 0; i <= endIndex; i++) {
            var j = Math.floor(Math.random() * (arrLen - i));

            if (array[i] === array[j]) {
                continue;
            }

            var _ref = [array[j], array[i]];
            array[i] = _ref[0];
            array[j] = _ref[1];
        }

        return array;
    }
};

module.exports = matrixToolkit;

/***/ })
/******/ ]);
//# sourceMappingURL=index.js.map