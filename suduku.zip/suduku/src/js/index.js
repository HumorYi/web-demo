const toolkit = require("./toolkit");

class Grid {
    constructor(container) {
        this._$container = container;
    }

    build() {
        const matrix = toolkit.makeMatrix();

        const rowGroupClasses = ["row_g_top", "row_g_middle", "row_g_bottom"];
        const colGroupClasses = ["col_g_left", "col_g_center", "col_g_right"];

        // 为矩阵中每列添加一个 span标签
        const $cells = matrix.map(rowValues => rowValues
            .map((cellValue, colIndex) => {
                return $("<span>")
                    .addClass(colGroupClasses[colIndex % 3])
                    .text(cellValue);
            }));

        // 为矩阵中的每行添加一个 div标签
        const $divArray = $cells.map(($spanArray, rowIndex) => {
            return $("<div>")
                .addClass("row")
                .addClass(rowGroupClasses[rowIndex % 3])
                .append($spanArray);
        });

        // 把矩阵添加到面板中去
        this._$container.append($divArray);
    }

    // 布局表格大小
    layout() {
        const width = $("span:first", this._$container).width();

        $("span", this._$container)
            .height(width)
            .css({
                "line-height": `${width}px`,
                "font-size": width < 32 ? `${width / 2}px`: ""
            });
    }
}

const grid = new Grid($("#container"));
grid.build();
grid.layout();