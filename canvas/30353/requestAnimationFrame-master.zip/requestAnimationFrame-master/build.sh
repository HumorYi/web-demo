uglifyjs requestAnimationFrame.js -m >requestAnimationFrame.min.js
